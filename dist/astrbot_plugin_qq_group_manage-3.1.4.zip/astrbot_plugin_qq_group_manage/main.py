from __future__ import annotations

import asyncio
import base64
import re
import secrets
import time
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote

from astrbot.api import AstrBotConfig, logger
from astrbot.api.event import AstrMessageEvent, MessageEventResult, filter
from astrbot.api.message_components import At, Image, Plain, Reply
from astrbot.api.star import Context, Star, StarTools, register
from astrbot.core.star.session_plugin_manager import SessionPluginManager
from astrbot.core.star.session_llm_manager import SessionServiceManager

from .api import QQ_PLATFORMS, QQGroupManageAPI
from .callback_guard import ReviewCallbackGuard
from .dashboard import DashboardAPI
from .durations import parse_duration
from .storage import PluginStorage
from .group_config import GroupConfig
from .keyword_rules import JOIN_REGEX_KEYS, compile_join_pattern, match_join_rules
from .lexicon_store import LexiconStore
from .join_verify import VERIFY_MODES
from .panel import (
    PANEL_IMAGE_KEYS,
    load_image,
    main_keyboard,
    manage_keyboard,
    parse_button,
)
from .settings_menu import (
    KEYWORD_VALUES,
    WORD_LISTS,
    keyword_summary,
    verify_summary,
    word_page,
)
from .server_status import ServerStatusService
from .spam_monitor import SpamMonitor
from .qr_detect import decoder_available, ensure_decoder, is_qr_code
from .recall_monitor import RecallMonitor
from .verify_flow import JoinVerifier

PLUGIN_NAME = "astrbot_plugin_qq_group_manage"
# 改名前的名称，仅用于兼容旧的 plugin_set 白名单配置。
LEGACY_PLUGIN_NAMES = ("astrbot_plugin_qq_group_admin",)

try:  # 跨平台按钮组件：AstrBot >= 4.29.4（钉钉互动卡片等）
    from astrbot.api.message_components import ActionRow, Button

    _PORTABLE_BUTTONS = True
except ImportError:  # 旧版 AstrBot 没有通用按钮组件，相关功能自动降级
    ActionRow = None
    Button = None
    _PORTABLE_BUTTONS = False

try:
    _register_button_action = filter.button_action
except AttributeError:
    _register_button_action = None


def _optional_button_action():
    """AstrBot >= 4.29.4 注册跨平台按钮处理；旧版本退化为空装饰器。"""
    if _register_button_action is not None:
        return _register_button_action()

    def decorator(func):
        return func

    return decorator


DINGTALK_PLATFORM = "dingtalk"
# 钉钉卡片回调的 spaceId 可能是完整 openSpaceId，统一剥掉前缀对齐群会话 ID。
DINGTALK_CARD_GROUP_PREFIX = "dtv1.card//IM_GROUP."
GROUP_MEMBER_INTENT = 1 << 24
GROUP_AND_C2C_INTENT = 1 << 25
INTERACTION_INTENT = 1 << 26
LIFECYCLE_INTENTS = GROUP_MEMBER_INTENT | GROUP_AND_C2C_INTENT | INTERACTION_INTENT
REVIEW_CALLBACK_RE = re.compile(
    r"^qqga:([0-9a-f]{32}):(approve|decline):(native|assigned|shared)$"
)
LIFECYCLE_EVENTS = (
    "group_join_request",
    "group_member_add",
    "group_member_remove",
)
ACTION_RE = re.compile(r"^/?(同意|通过|拒绝|驳回)(?:\s+(.+))?$", re.S)
APPLY_SOURCE_NAMES = {
    "self_apply": "自主申请",
    "search": "搜索群聊申请",
    "scan_qr_code": "扫描二维码申请",
    "group_card": "群分享卡片申请",
    "shared_card": "群分享卡片申请",
    "invited": "受邀加入",
    "invite": "受邀加入",
    "admin_invite": "管理员邀请",
}
LINK_PATTERN = re.compile(
    r"(?:(?:https?|ftp)://|www\.)[^\s<>\"'，。【】！？、]+"
    r"|(?<![A-Za-z0-9])(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+"
    r"(?:com|cn|net|org|io|cc|top|xyz|me|tv|info|biz|vip|club|site|online|link|"
    r"app|dev|ai|gg|so|co|us|uk|jp|hk|tw|ru|de|fr|eu|au|ca|in|kr|sg|asia|mobi|"
    r"name|pro|shop|store|work|live|fun|space|website|tech|cloud|blog|wiki)"
    r"(?![A-Za-z0-9])"
    r"(?:/[^\s<>\"'，。【】！？、]*)?",
    re.IGNORECASE,
)


def contains_link(text: str) -> bool:
    """Whether the plain-text content contains a URL or a common domain name."""
    return bool(LINK_PATTERN.search(text or ""))


@dataclass(frozen=True)
class FeatureDefinition:
    name: str
    key: str
    category: str
    default: bool = True
    inverted: bool = False


FEATURES = (
    FeatureDefinition("禁言指令", "enable_mute_command", "群内指令"),
    FeatureDefinition(
        "禁言成功提示",
        "silent_mute_success_notice",
        "群内指令",
        default=False,
        inverted=True,
    ),
    FeatureDefinition("禁言状态指令", "enable_mute_status_command", "群内指令"),
    FeatureDefinition("群管指令", "enable_group_admin_commands", "群内指令"),
    FeatureDefinition("入群申请通知", "enable_join_notice", "自动通知"),
    FeatureDefinition("入群申请审批", "enable_join_reply_review", "自动通知"),
    FeatureDefinition("成员进群通知", "enable_member_join_notice", "自动通知"),
    FeatureDefinition("成员退群通知", "enable_member_leave_notice", "自动通知"),
    FeatureDefinition(
        "入群关键词审批", "enable_join_keyword_review", "关键词管理", default=False
    ),
    FeatureDefinition(
        "违禁词撤回", "enable_keyword_recall", "风险消息撤回", default=False
    ),
    FeatureDefinition(
        "链接消息撤回", "enable_link_recall", "风险消息撤回", default=False
    ),
    FeatureDefinition(
        "二维码图片撤回", "enable_qr_recall", "风险消息撤回", default=False
    ),
    FeatureDefinition("进群验证", "enable_join_verify", "进群验证", default=False),
    FeatureDefinition("刷屏监控", "enable_anti_spam", "刷屏监控", default=False),
    FeatureDefinition("LLM禁言工具", "enable_mute_tool", "LLM 工具"),
    FeatureDefinition("LLM解禁工具", "enable_unmute_tool", "LLM 工具"),
    FeatureDefinition("LLM禁言状态工具", "enable_mute_status_tool", "LLM 工具"),
    FeatureDefinition("LLM申请列表工具", "enable_join_list_tool", "LLM 工具"),
    FeatureDefinition("LLM申请审批工具", "enable_join_review_tool", "LLM 工具"),
)
FEATURES_BY_NAME = {feature.name: feature for feature in FEATURES}

CONFIG_SECTIONS = {
    "enabled_group_umos": "scope_settings",
    "enable_per_group_feature_settings": "scope_settings",
    "allow_group_owner_manage_plugin_admins": "permission_settings",
    "allow_group_admin_manage_plugin_admins": "permission_settings",
    "enable_mute_command": "command_settings",
    "enable_mute_status_command": "command_settings",
    "enable_group_admin_commands": "command_settings",
    "silent_mute_success_notice": "command_settings",
    "default_mute_duration": "command_settings",
    "enable_join_notice": "join_request_settings",
    "enable_join_reply_review": "join_request_settings",
    "join_request_page_size": "join_request_settings",
    "pending_retention_days": "join_request_settings",
    "enable_member_join_notice": "member_notice_settings",
    "member_join_message": "member_notice_settings",
    "enable_member_leave_notice": "member_notice_settings",
    "member_leave_message": "member_notice_settings",
    "enable_mute_tool": "llm_tool_settings",
    "enable_unmute_tool": "llm_tool_settings",
    "enable_mute_status_tool": "llm_tool_settings",
    "enable_join_list_tool": "llm_tool_settings",
    "enable_join_review_tool": "llm_tool_settings",
    "strict_llm_permissions": "llm_tool_settings",
    "max_mute_seconds": "limit_settings",
    "enable_join_keyword_review": "keyword_settings",
    "join_whitelist_words": "keyword_settings",
    "join_blacklist_words": "keyword_settings",
    "join_keyword_priority": "keyword_settings",
    "join_keyword_match_mode": "keyword_settings",
    "enable_keyword_recall": "keyword_settings",
    "keyword_recall_notice": "keyword_settings",
    "enable_link_recall": "keyword_settings",
    "link_recall_notice": "keyword_settings",
    "enable_qr_recall": "keyword_settings",
    "qr_recall_notice": "keyword_settings",
    "enable_join_verify": "verify_settings",
    "verify_mode": "verify_settings",
    "arithmetic_ops": "verify_settings",
    "arithmetic_max_number": "verify_settings",
    "custom_questions": "verify_settings",
    "verify_max_failures": "verify_settings",
    "verify_fail_mute_duration": "verify_settings",
    "verify_timeout_minutes": "verify_settings",
    "verify_timeout_action": "verify_settings",
    "verify_prompt": "verify_settings",
    "enable_anti_spam": "spam_settings",
    "spam_limit_1s": "spam_settings",
    "spam_limit_1m": "spam_settings",
    "spam_limit_1h": "spam_settings",
    "spam_night_enabled": "spam_settings",
    "spam_night_limit": "spam_settings",
    "spam_mute_duration": "spam_settings",
    "spam_recall_threshold": "spam_settings",
}

PANEL_FEATURE_KEYS = {
    "enable_join_notice",
    "enable_join_reply_review",
    "enable_join_verify",
    "enable_keyword_recall",
    "enable_qr_recall",
    "enable_link_recall",
}

LEGACY_CONFIG_KEYS = tuple(
    key
    for key in CONFIG_SECTIONS
    if CONFIG_SECTIONS[key] not in {"keyword_settings", "verify_settings", "spam_settings"}
    and key
    not in {
        "enable_per_group_feature_settings",
        "allow_group_owner_manage_plugin_admins",
        "allow_group_admin_manage_plugin_admins",
        "strict_llm_permissions",
    }
)


def format_feature_status(
    values: dict[str, bool],
    *,
    per_group: bool,
) -> str:
    lines = [
        "# 🛡️ 群管功能",
        "",
        f"当前开关模式：**{'分群' if per_group else '全局'}**",
    ]
    for category in dict.fromkeys(feature.category for feature in FEATURES):
        lines.extend(("", f"## {category}", ""))
        for feature in FEATURES:
            if feature.category != category:
                continue
            enabled = values[feature.name]
            status = "已开启" if enabled else "已关闭"
            next_action = "关闭" if enabled else "开启"
            command = quote(
                f"群管功能 {feature.name} {next_action}",
                safe="",
            )
            status = (
                f"[{status}]"
                f"(mqqapi://aio/inlinecmd?command={command}"
                "&enter=false&reply=false)"
            )
            lines.append(f"{feature.name}：{status}  ")
    if per_group:
        lines.extend(("", "> 点击蓝色状态可把相反操作填入输入框，不会自动发送。"))
    else:
        lines.extend(("", "> 全局模式只有框架管理员允许更改"))
    return "\n".join(lines)


def intent_value(value: Any) -> int:
    if isinstance(value, int):
        return value
    raw = getattr(value, "value", 0)
    return raw if isinstance(raw, int) else 0


def contains_keyword(text: str, words: list[str]) -> bool:
    """Match literal substrings, ignoring empty entries and letter case."""
    text = text.casefold()
    return any(word.strip().casefold() in text for word in words if word.strip())


def join_keyword_decision(
    item: dict[str, Any],
    whitelist: list[str],
    blacklist: list[str],
    priority: str,
    mode: str = "包含匹配",
) -> bool | None:
    """Inspect answers only; questions, nicknames and verification messages are excluded."""
    if item.get("auto_approved"):
        return None
    answers = [
        qa.get("answer") or ""
        for qa in (item.get("verify_info") or {}).get("review_qa_list") or []
    ]
    rules = [(False, blacklist), (True, whitelist)]
    if priority == "白词优先":
        rules.reverse()
    if mode == "正则匹配":
        return match_join_rules(answers, rules)
    for approve, words in rules:
        if any(contains_keyword(answer, words) for answer in answers):
            return approve
    return None


def format_request(item: dict[str, Any], *, markdown: bool = False) -> str:
    lines = [
        "入群申请已自动通过" if item.get("auto_approved") else "新的入群申请",
        f"昵称：{item.get('username') or '未提供'}",
        f"申请时间：{item.get('apply_at') or '未提供'}",
        "来源：" + format_apply_source(item.get("apply_source")),
    ]
    if item.get("risk_tips"):
        lines.append(f"风险提示：{item['risk_tips']}")
    verify = item.get("verify_info") or {}
    if verify.get("verify_message"):
        lines.append(f"验证消息：{verify['verify_message']}")
    qa_list = verify.get("review_qa_list") or []
    for qa in qa_list:
        lines.append(
            f"问题：{qa.get('question') or '（无问题）'}\n"
            f"答：{qa.get('answer') or '（未回答）'}"
        )
    if item.get("auto_approved"):
        lines.append(
            f"自动审批策略：{item['auto_approved'].get('strategy_id') or '已自动通过'}"
        )
    if markdown:
        # All fields come from external users/API payloads, not trusted Markdown.
        fields = [
            re.sub(r"([\\`*_{}\[\]()#+.!|<>~-])", r"\\\1", line)
            for field in lines[1:]
            for line in field.splitlines()
        ]
        title = "入群申请已自动通过" if item.get("auto_approved") else "入群申请"
        return f"# 📨 {title}\n\n" + "  \n".join(fields)
    return "\n".join(lines)


def format_apply_source(value: Any) -> str:
    source = str(value or "").strip()
    if not source:
        return "未提供"
    return APPLY_SOURCE_NAMES.get(source.lower(), "其他来源")


def review_keyboard(
    callbacks: dict[str, dict[str, str]], admin_ids: list[str]
) -> dict[str, Any]:
    """Restrict both rows in QQ; assigned admins are also rechecked on callback."""

    def button(token: str, action: str, audience: str) -> dict[str, Any]:
        label = ("群管" if audience == "native" else "授权") + (
            "同意" if action == "approve" else "拒绝"
        )
        return {
            "id": f"qqga-{action}-{audience}",
            "render_data": {
                "label": label,
                "visited_label": label,
                "style": 1 if action == "approve" else 0,
            },
            "action": {
                "type": 1,
                "permission": {"type": 1}
                if audience == "native"
                else {"type": 0, "specify_user_ids": admin_ids},
                "data": f"qqga:{token}:{action}:{audience}",
                "unsupport_tips": "请更新 QQ 客户端，或引用申请通知回复 同意 / 拒绝",
            },
        }

    rows = [
        {
            "buttons": [
                button(token, binding["action"], audience)
                for token, binding in callbacks.items()
                if binding["audience"] == audience
            ]
        }
        for audience in ("native", "assigned")
        if audience == "native" or admin_ids
    ]
    return {"content": {"rows": rows}}


def format_mute_status(result: dict[str, Any]) -> str:
    global_rule = result.get("global_rule") or {}
    mode = global_rule.get("mode") or "none"
    mode_text = {
        "none": "未开启",
        "always": "始终全员禁言",
        "schedule": "按规则全员禁言",
    }.get(mode, f"未知模式（{mode}）")
    lines = ["本群禁言状态", f"全员禁言：{mode_text}"]

    schedule_rules = global_rule.get("schedule_rules") or []
    if schedule_rules:
        lines.append("定时规则：")
        for rule in schedule_rules:
            enabled = "启用" if rule.get("enabled") else "停用"
            lines.append(
                f"- [{enabled}] {rule.get('start_at') or '未知'} 至 "
                f"{rule.get('end_at') or '未知'}（{rule.get('task_id') or '无任务 ID'}）"
            )

    recurring_rules = global_rule.get("recurring_rules") or []
    if recurring_rules:
        weekday_names = {1: "一", 2: "二", 3: "三", 4: "四", 5: "五", 6: "六", 7: "日"}
        lines.append("周期规则：")
        for rule in recurring_rules:
            enabled = "启用" if rule.get("enabled") else "停用"
            weekdays = (
                "、".join(
                    f"周{weekday_names.get(day, day)}"
                    for day in rule.get("weekdays", [])
                )
                or "未指定星期"
            )
            lines.append(
                f"- [{enabled}] {weekdays} {rule.get('start_time') or '未知'}-"
                f"{rule.get('end_time') or '未知'}（{rule.get('task_id') or '无任务 ID'}）"
            )

    members = result.get("members") or []
    lines.append(f"单独禁言成员：{len(members)} 人")
    for member in members:
        username = member.get("username") or "未知昵称"
        member_openid = member.get("member_openid") or "未知 OpenID"
        expire_at = member.get("mute_expire_at") or "未知"
        lines.append(f"- {username}（{member_openid}），到期：{expire_at}")
    return "\n".join(lines)


def format_group_admin_help(default_duration: str) -> str:
    return (
        "# 🛡️ QQ 群管帮助\n\n"
        "@机器人后直接发送下列指令，无需添加 `/`；也可使用 AstrBot 中配置的唤醒词。\n\n"
        "## 成员管理\n\n"
        "> `禁言 @用户 [时间]`  \n"
        f"> 禁言成员；不填时间默认 **{default_duration}**\n\n"
        "> `解禁 @用户`  \n"
        "> 解除成员禁言\n\n"
        "> `踢人 @用户`  \n"
        "> 批量移出群成员；单次最多 20 人\n\n"
        "> `禁言状态`  \n"
        "> 查看全员禁言规则及被禁言成员\n\n"
        "## 群管管理\n\n"
        "> `添加群管 @用户`  \n"
        "> 添加本群插件群管；默认仅 AstrBot 管理员可用\n\n"
        "> `删除群管 @用户`  \n"
        "> 删除本群插件群管；可在配置中授权 QQ 群主或群管理员\n\n"
        "> `群管列表`  \n"
        "> 查看本群群管\n\n"
        "> `群管功能`  \n"
        "> 查看功能开关；点击蓝色状态填入切换指令，发送后生效\n\n"
        "> `菜单`  \n"
        "> 发送带按钮的淼淼菜单：功能列表、使用指南、获取帮助和群管面板\n\n"
        "> `群绑定 群号 [群名]`  \n"
        "> 把本群 group_openid 绑定到 QQ 群号备注，例如 `群绑定 123456789 天文社`；只影响控制台显示\n\n"
        "## 时间格式\n\n"
        "支持 `30秒`、`10分`、`2小时`、`1天2小时`  \n"
        "纯数字按分钟处理，例如 `30` 表示 **30分钟**\n\n"
        "## 入群审批\n\n"
        "点击申请通知下方的同意 / 拒绝按钮，直接完成审批。\n\n"
        "第一行「群管同意 / 群管拒绝」：QQ 群主、QQ 群管理员可操作。\n\n"
        "第二行「授权同意 / 授权拒绝」：发卡时的 AstrBot 管理员和本群插件群管可操作，点击时会再次检查授权。\n\n"
        "拒绝并填写理由时，可引用申请通知回复 `拒绝 理由`。\n\n"
        "## 进群验证\n\n"
        "> `验证列表`  \n"
        "> 查看本群未完成验证的成员\n\n"
        "> `验证放行 @用户`  \n"
        "> 跳过验证；验证失败被禁言的成员会同时解禁\n\n"
        "> `重新验证 @用户`  \n"
        "> 重新出题，答错次数清零\n\n"
        "---\n\n"
        "💡 AstrBot 管理员拥有全局权限；插件群管和 QQ 群主/管理员拥有本群普通群管权限。"
    )


def resolve_tool_event(value: Any) -> AstrMessageEvent:
    """Accept both legacy AstrMessageEvent and AstrBot 4.26 ContextWrapper."""
    if hasattr(value, "get_platform_name") and hasattr(value, "get_group_id"):
        return value
    context = getattr(value, "context", None)
    event = getattr(context, "event", None)
    if event is None:
        event = getattr(getattr(context, "context", None), "event", None)
    if event is None:
        raise RuntimeError("无法从 AstrBot 工具上下文中取得消息事件")
    return event


def review_action_text(event: AstrMessageEvent) -> str:
    """Read only newly typed plain text, excluding quote and mention components."""
    return "".join(
        str(getattr(part, "text", "") or "")
        for part in event.get_messages()
        if isinstance(part, Plain)
    ).strip()


def qq_field(value: Any, name: str) -> Any:
    return value.get(name) if isinstance(value, dict) else getattr(value, name, None)


def review_quote(event: AstrMessageEvent) -> set[str] | None:
    """Read only the immediate quote's IDs, never the current message's msg_idx."""
    reply = next((p for p in event.get_messages() if isinstance(p, Reply)), None)
    references = {str(reply.id)} if reply is not None and reply.id else set()

    # Older adapters may preserve QQ's quote fields without building a Reply.
    raw = getattr(event.message_obj, "raw_message", None)
    quoted = reply is not None
    for source in (raw, qq_field(raw, "raw_data")):
        reference_id = qq_field(qq_field(source, "message_reference"), "message_id")
        if reference_id:
            quoted = True
            references.add(str(reference_id))
        ext = qq_field(qq_field(source, "message_scene"), "ext")
        if isinstance(ext, list):
            for entry in ext:
                if not isinstance(entry, str):
                    continue
                key, separator, value = entry.partition("=")
                if separator and key.strip() == "ref_msg_idx":
                    quoted = True
                    if value.strip():
                        references.add(value.strip())
        if str(qq_field(source, "message_type")) == "103":
            quoted = True
            elements = qq_field(source, "msg_elements")
            if isinstance(elements, list) and elements:
                for key in ("id", "message_id", "msg_idx"):
                    value = qq_field(elements[0], key)
                    if value:
                        references.add(str(value))
    return references if quoted else None


@register(
    PLUGIN_NAME,
    "简单么么熊",
    "QQ 官方机器人群管理：禁言、入群申请审批、分群管理员与 LLM 工具",
    "3.1.4",
)
class QQGroupAdminPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig) -> None:
        super().__init__(context)
        self.config = config
        self._migrate_config_layout()
        data_dir = StarTools.get_data_dir(PLUGIN_NAME)
        self.storage = PluginStorage(
            data_dir / "state.json",
            int(self._config("pending_retention_days", 30)),
        )
        unresolved = GroupConfig(self.config).migrate(self.storage, self.context)
        if unresolved:
            logger.warning(
                "[%s] 以下旧分群记录需要在 UMO 列表核对：%s", PLUGIN_NAME, unresolved
            )
        self._patched: dict[str, dict[str, Any]] = {}
        self._patch_task: asyncio.Task | None = None
        self._sdk_event_tasks: set[asyncio.Task] = set()
        self._terminating = False
        self._parser_state_class: Any = None
        self._owned_parser_methods: dict[str, Any] = {}
        self._reviews_inflight: set[tuple[str, str, str]] = set()
        self._callback_guard = ReviewCallbackGuard()
        self.spam_monitor = SpamMonitor()
        self.recall_monitor = RecallMonitor()
        self.lexicons = LexiconStore(data_dir)
        self.server_status = ServerStatusService(data_dir, self)
        self.verifier = JoinVerifier(self)
        self._verify_task: asyncio.Task | None = None
        self._qr_dep_task: asyncio.Task | None = None
        self.dashboard = DashboardAPI(self)
        try:
            self.dashboard_available = self.dashboard.register()
        except Exception:
            self.dashboard_available = False
            logger.exception(
                "[%s] 注册 WebUI 视图 API 失败，插件其余功能继续运行",
                PLUGIN_NAME,
            )
        self._install_parser_patch()

    async def initialize(self) -> None:
        """Install the optional QR decoder and start server sampling."""
        await self.server_status.start()
        if decoder_available() or self._qr_dep_task is not None:
            return
        self._qr_dep_task = asyncio.create_task(self._install_qr_decoder())

    async def _install_qr_decoder(self) -> None:
        try:
            if await ensure_decoder():
                logger.info("[%s] 二维码识别依赖已就绪", PLUGIN_NAME)
            else:
                logger.warning(
                    "[%s] 二维码识别依赖不可用，如需识别二维码请手动执行："
                    "pip install zxing-cpp",
                    PLUGIN_NAME,
                )
        finally:
            self._qr_dep_task = None

    def _install_parser_patch(self) -> None:
        """Install parsers before QQ connections snapshot ConnectionState methods."""
        try:
            from botpy.connection import ConnectionState
        except Exception:
            logger.exception("[%s] 无法加载 QQ 事件解析器", PLUGIN_NAME)
            return

        self._parser_state_class = ConnectionState
        for event_name in LIFECYCLE_EVENTS:
            attr = f"parse_{event_name}"
            if hasattr(ConnectionState, attr):
                continue

            def parser(
                state: Any,
                payload: dict[str, Any],
                dispatched_event: str = event_name,
            ) -> None:
                data = dict(payload.get("d", {}) or {})
                data["_event_id"] = str(payload.get("id") or "")
                state._dispatch(dispatched_event, data)

            parser.__name__ = attr
            parser.__qualname__ = f"ConnectionState.{attr}"
            setattr(parser, "__qq_group_manage_parser__", True)
            setattr(ConnectionState, attr, parser)
            self._owned_parser_methods[attr] = parser

        if self._owned_parser_methods:
            logger.info(
                "[%s] 已预安装 QQ 入群申请与成员进退群解析器",
                PLUGIN_NAME,
            )

    @filter.on_astrbot_loaded()
    async def on_astrbot_loaded(self) -> None:
        self._start_patch_task()

    @filter.on_platform_loaded()
    async def on_platform_loaded(self) -> None:
        await self._patch_platforms_once()

    @filter.on_plugin_loaded()
    async def on_plugin_loaded(self, metadata: Any) -> None:
        """Handle installation or hot reload after QQ platforms are already running."""
        await self._patch_platforms_once()
        self._start_patch_task()

    def _start_patch_task(self) -> None:
        if self._terminating:
            return
        if self._patch_task is None or self._patch_task.done():
            self._patch_task = asyncio.create_task(self._patch_platforms_until_ready())
        if self._verify_task is None or self._verify_task.done():
            self._verify_task = asyncio.create_task(self.verifier.run())

    async def _run_sdk_event(self, handler: Any, *args: Any) -> Any:
        # Own only our work, not the SDK dispatch task or another plugin's handler.
        # A dispatch queued before unloading must not start work on the old instance.
        if self._terminating:
            return None
        task = asyncio.create_task(handler(*args))
        self._sdk_event_tasks.add(task)
        try:
            return await task
        finally:
            self._sdk_event_tasks.discard(task)

    async def _patch_platforms_until_ready(self) -> None:
        for _ in range(60):
            await self._patch_platforms_once()
            await asyncio.sleep(2)

    async def _patch_platforms_once(self) -> None:
        for platform in self.context.platform_manager.platform_insts:
            if self._terminating:
                return
            try:
                meta = platform.meta()
            except Exception:
                continue
            if meta.name not in QQ_PLATFORMS:
                continue
            client = getattr(platform, "client", None)
            if client is None:
                continue
            platform_id = meta.id
            if (
                platform_id in self._patched
                and self._patched[platform_id]["client"] is not client
            ):
                # Platform reload keeps its ID but replaces the SDK client.
                self._restore_client_handlers(self._patched.pop(platform_id))
            if platform_id not in self._patched:
                old_handlers = {
                    name: getattr(client, name, None)
                    for name in (
                        "on_group_join_request",
                        "on_group_member_add",
                        "on_group_member_remove",
                        "on_group_add_robot",
                        "on_group_del_robot",
                        "on_interaction_create",
                    )
                }

                async def handler(
                    data: dict[str, Any],
                    pid: str = platform_id,
                    original: Any = old_handlers["on_group_join_request"],
                ) -> None:
                    await self._run_sdk_event(
                        self._handle_join_request_event, pid, data
                    )
                    if original is not None:
                        result = original(data)
                        if hasattr(result, "__await__"):
                            await result

                async def member_add_handler(
                    data: dict[str, Any],
                    pid: str = platform_id,
                    original: Any = old_handlers["on_group_member_add"],
                ) -> None:
                    # 先登记待验证再发欢迎，欢迎消息发送期间的发言也会被拦截。
                    record = await self._run_sdk_event(self.verifier.prepare, pid, data)
                    await self._run_sdk_event(
                        self._handle_member_event, pid, "member_join", data
                    )
                    if record is not None:
                        await self._run_sdk_event(self.verifier.deliver, pid, record)
                    if original is not None:
                        result = original(data)
                        if hasattr(result, "__await__"):
                            await result

                async def member_remove_handler(
                    data: dict[str, Any],
                    pid: str = platform_id,
                    original: Any = old_handlers["on_group_member_remove"],
                ) -> None:
                    await self._run_sdk_event(
                        self._handle_member_event, pid, "member_leave", data
                    )
                    await self._run_sdk_event(self.verifier.clear, pid, data)
                    if original is not None:
                        result = original(data)
                        if hasattr(result, "__await__"):
                            await result

                async def robot_removed_handler(
                    data: dict[str, Any],
                    pid: str = platform_id,
                    original: Any = old_handlers["on_group_del_robot"],
                ) -> None:
                    await self._run_sdk_event(self._handle_robot_removed, pid, data)
                    if original is not None:
                        result = original(data)
                        if hasattr(result, "__await__"):
                            await result

                async def robot_added_handler(
                    data: dict[str, Any],
                    pid: str = platform_id,
                    original: Any = old_handlers["on_group_add_robot"],
                ) -> None:
                    await self._run_sdk_event(self._handle_robot_added, pid, data)
                    if original is not None:
                        result = original(data)
                        if hasattr(result, "__await__"):
                            await result

                setattr(client, "on_group_join_request", handler)
                setattr(client, "on_group_member_add", member_add_handler)
                setattr(client, "on_group_member_remove", member_remove_handler)
                setattr(client, "on_group_del_robot", robot_removed_handler)
                setattr(client, "on_group_add_robot", robot_added_handler)

                async def interaction_handler(
                    interaction: Any,
                    pid: str = platform_id,
                    original: Any = old_handlers["on_interaction_create"],
                ) -> None:
                    if await self._run_sdk_event(
                        self._handle_panel_interaction, pid, interaction
                    ):
                        return
                    if await self._run_sdk_event(
                        self.verifier.handle_interaction, pid, interaction
                    ):
                        return
                    if await self._run_sdk_event(
                        self._handle_review_interaction, pid, interaction
                    ):
                        return
                    if original is not None:
                        await original(interaction)

                setattr(client, "on_interaction_create", interaction_handler)
                self._patched[platform_id] = {
                    "client": client,
                    "old_handlers": old_handlers,
                    "owned_handlers": {
                        name: getattr(client, name) for name in old_handlers
                    },
                    "connections": {},
                }
            patch_state = self._patched[platform_id]
            if meta.name == "qq_official":
                await self._ensure_group_member_intent(platform, client)
            if self._terminating:
                return
            connections = [getattr(client, "_connection", None)]
            webhook_helper = getattr(platform, "webhook_helper", None)
            connections.append(getattr(webhook_helper, "_connection", None))
            for connection in connections:
                if connection is None or id(connection) in patch_state["connections"]:
                    continue

                def join_request_parser(
                    payload: dict[str, Any], c: Any = client
                ) -> None:
                    data = dict(payload.get("d", {}) or {})
                    data["_event_id"] = str(payload.get("id") or "")
                    c.ws_dispatch("group_join_request", data)

                def member_add_parser(payload: dict[str, Any], c: Any = client) -> None:
                    data = dict(payload.get("d", {}) or {})
                    data["_event_id"] = str(payload.get("id") or "")
                    c.ws_dispatch("group_member_add", data)

                def member_remove_parser(
                    payload: dict[str, Any], c: Any = client
                ) -> None:
                    data = dict(payload.get("d", {}) or {})
                    data["_event_id"] = str(payload.get("id") or "")
                    c.ws_dispatch("group_member_remove", data)

                parsers = {
                    "group_join_request": join_request_parser,
                    "group_member_add": member_add_parser,
                    "group_member_remove": member_remove_parser,
                }
                patch_state["connections"][id(connection)] = (
                    connection,
                    {name: connection.parser.get(name) for name in parsers},
                    parsers,
                )
                connection.parser.update(parsers)
                logger.info("[%s] 已接入 QQ 入群申请与成员进退群事件", PLUGIN_NAME)

    async def _ensure_group_member_intent(self, platform: Any, client: Any) -> None:
        current = intent_value(getattr(client, "intents", 0))
        required = current | LIFECYCLE_INTENTS
        if current != required:
            client.intents = required
            platform_intents = getattr(platform, "intents", None)
            if hasattr(platform_intents, "value"):
                platform_intents.value = (
                    intent_value(platform_intents) | LIFECYCLE_INTENTS
                )
            logger.info(
                "[%s] 已启用群生命周期和按钮回调 Intents，当前值：%s",
                PLUGIN_NAME,
                required,
            )

        connection = getattr(client, "_connection", None)
        pending_sessions = getattr(connection, "_session_list", None) or []
        for session in pending_sessions:
            if isinstance(session, dict):
                session["intent"] = required

        for websocket in list(getattr(client, "_active_websockets", None) or []):
            session = getattr(websocket, "_session", None)
            if not isinstance(session, dict):
                continue
            if (
                intent_value(session.get("intent", 0)) & LIFECYCLE_INTENTS
                == LIFECYCLE_INTENTS
            ):
                continue
            session["intent"] = required
            session["session_id"] = ""
            session["last_seq"] = 0
            try:
                close = getattr(websocket, "close", None)
                if callable(close):
                    await close()
                else:
                    socket = getattr(websocket, "_conn", None)
                    if socket is not None and not getattr(socket, "closed", True):
                        websocket._can_reconnect = False
                        await socket.close()
                logger.info(
                    "[%s] 已重连 QQ WebSocket 以应用群生命周期 Intents",
                    PLUGIN_NAME,
                )
            except Exception:
                logger.exception("[%s] 应用群生命周期 Intents 时重连失败", PLUGIN_NAME)

    async def _handle_member_event(
        self,
        platform_id: str,
        notice_type: str,
        item: dict[str, Any],
    ) -> None:
        enabled_key = (
            "enable_member_join_notice"
            if notice_type == "member_join"
            else "enable_member_leave_notice"
        )
        group_openid = str(item.get("group_openid") or "")
        member_openid = str(item.get("member_openid") or "")
        if not group_openid:
            logger.warning("[%s] 成员事件缺少 group_openid: %r", PLUGIN_NAME, item)
            return
        group_umo = self._group_umo(platform_id, group_openid)
        if not await self._sdk_group_enabled(group_umo):
            return
        if not self._feature_setting(enabled_key, group_umo):
            return
        template_key = (
            "member_join_message"
            if notice_type == "member_join"
            else "member_leave_message"
        )
        default = (
            "欢迎 {member_at} 加入群聊！"
            if notice_type == "member_join"
            else "有成员退出了群聊。"
        )
        template = str(
            self._group_setting(template_key, group_umo, default) or ""
        ).strip()
        if not template:
            return
        platform = self.context.get_platform_inst(platform_id)
        if platform is None:
            return
        can_at = notice_type == "member_join"
        content = render_member_notice(
            template,
            member_openid,
            can_at=can_at,
            appid=str(getattr(platform, "appid", "") or ""),
        )
        if not content.strip():
            return
        api = QQGroupManageAPI(platform.client)
        try:
            if "<qqbot-at-user" in content or "![头像 #" in content:
                try:
                    await api.send_group_markdown(
                        group_openid,
                        content,
                    )
                except Exception:
                    logger.warning(
                        "[%s] 成员通知 Markdown 发送失败，降级为普通文本",
                        PLUGIN_NAME,
                        exc_info=True,
                    )
                    fallback = render_member_notice(
                        template,
                        member_openid,
                        can_at=False,
                    ).strip()
                    if fallback:
                        await api.send_group_text(group_openid, fallback)
            else:
                await api.send_group_text(
                    group_openid,
                    content,
                )
        except Exception:
            logger.exception("[%s] 成员进退群通知发送失败", PLUGIN_NAME)

    async def _handle_robot_added(
        self, platform_id: str, item: dict[str, Any]
    ) -> None:
        """GROUP_ADD_ROBOT: make a newly joined group visible immediately."""
        group_openid = str(item.get("group_openid") or "").strip()
        if not group_openid:
            logger.warning("[%s] 机器人进群事件缺少 group_openid: %r", PLUGIN_NAME, item)
            return
        try:
            changed = self.storage.remember_group(platform_id, group_openid)
        except Exception:
            logger.exception("[%s] 记录机器人新进群失败", PLUGIN_NAME)
            return
        logger.info(
            "[%s] 机器人加入群 %s，已%s已知群记录",
            PLUGIN_NAME,
            group_openid,
            "更新" if changed else "保留",
        )

    async def _handle_robot_removed(
        self, platform_id: str, item: dict[str, Any]
    ) -> None:
        """GROUP_DEL_ROBOT: remove every local trace of a group after removal."""
        group_openid = str(item.get("group_openid") or "").strip()
        if not group_openid:
            logger.warning("[%s] 机器人退群事件缺少 group_openid: %r", PLUGIN_NAME, item)
            return
        umo = self._group_umo(platform_id, group_openid)
        try:
            result = self.storage.purge_group(platform_id, group_openid)
        except Exception:
            logger.exception("[%s] 自动清理退群群数据失败", PLUGIN_NAME)
            return
        try:
            config_removed = GroupConfig(self.config).remove(umo)
        except Exception:
            logger.exception("[%s] 自动删除退群群配置失败", PLUGIN_NAME)
            config_removed = False
        logger.warning(
            "[%s] 机器人被移出群 %s，已直接清理群记录（配置=%s，待审=%s，验证=%s）",
            PLUGIN_NAME,
            group_openid,
            config_removed,
            result.get("pending", 0),
            result.get("verifications", 0),
        )

    async def _handle_join_request_event(
        self, platform_id: str, item: dict[str, Any]
    ) -> None:
        group_openid = str(item.get("group_openid") or "")
        if not group_openid:
            logger.warning("[%s] 入群申请缺少 group_openid: %r", PLUGIN_NAME, item)
            return
        group_umo = self._group_umo(platform_id, group_openid)
        if not await self._sdk_group_enabled(group_umo):
            return
        request_key = (
            platform_id,
            group_openid,
            str(item.get("join_request_id") or ""),
        )
        if self.storage.is_reviewed(*request_key):
            return
        auto_approved = bool(item.get("auto_approved"))
        if auto_approved:
            self._record_reviewed_request(*request_key)
        notice_enabled = self._feature_setting("enable_join_notice", group_umo)
        auto_review_enabled = self._feature_setting(
            "enable_join_keyword_review", group_umo, False
        )
        if not notice_enabled and not auto_review_enabled:
            return
        platform = self.context.get_platform_inst(platform_id)
        if platform is None:
            return
        if auto_review_enabled and await self._auto_review_join_request(
            platform_id, platform.client, item
        ):
            return
        if not notice_enabled:
            return
        stored = dict(item)
        stored["platform_id"] = platform_id
        stored["group_openid"] = group_openid
        admin_ids = []
        pending_key = ""
        if not auto_approved:
            # Reservation is synchronous: a replay cannot replace the first
            # notification's tokens while its send is still awaiting QQ.
            if (
                self.storage.find_pending_by_join_request_id(
                    str(item.get("join_request_id") or ""), group_openid, platform_id
                )
                is not None
            ):
                return
            admin_ids = self._callback_admin_ids(platform_id, group_openid)
            stored["review_callbacks"] = {
                secrets.token_hex(16): {"action": action, "audience": audience}
                for audience in ("native", "assigned")
                if audience == "native" or admin_ids
                for action in ("approve", "decline")
            }
            pending_key = self.storage.reserve_pending(stored)
        content = format_request(item, markdown=True)
        review_enabled = not auto_approved and self._feature_setting(
            "enable_join_reply_review",
            group_umo,
        )
        if review_enabled:
            content += "\n\n点击下方按钮直接审批；或引用本消息：同意/拒绝 理由。"
        try:
            api = QQGroupManageAPI(platform.client)
            try:
                result = await api.send_group_markdown(
                    group_openid,
                    content,
                    keyboard=review_keyboard(stored["review_callbacks"], admin_ids)
                    if review_enabled
                    else None,
                )
            except Exception:
                logger.warning(
                    "[%s] 入群申请 Markdown 按钮发送失败，降级为纯文本通知",
                    PLUGIN_NAME,
                    exc_info=True,
                )
                fallback = format_request(item)
                if review_enabled:
                    fallback += (
                        "\n\n按钮暂不可用，可引用本消息回复：同意 / 拒绝 [理由]。"
                    )
                result = await api.send_group_text(group_openid, fallback)
            message_id = self._response_id(result)
            ref_idx = str(qq_field(qq_field(result, "ext_info"), "ref_idx") or "")
            if pending_key and (message_id or ref_idx):
                pending_key = self.storage.bind_pending_message(
                    pending_key,
                    message_id,
                    ref_idx,
                )
        except (Exception, asyncio.CancelledError) as exc:
            if pending_key:
                self.storage.remove_pending(pending_key)
            if isinstance(exc, asyncio.CancelledError):
                raise
            logger.exception("[%s] 转发入群申请失败", PLUGIN_NAME)

    async def _auto_review_join_request(
        self, platform_id: str, client: Any, item: dict[str, Any]
    ) -> bool:
        group_umo = self._group_umo(platform_id, str(item.get("group_openid") or ""))
        try:
            approve = join_keyword_decision(
                item,
                self._group_setting("join_whitelist_words", group_umo, []),
                self._group_setting("join_blacklist_words", group_umo, []),
                self._group_setting("join_keyword_priority", group_umo, "黑词优先"),
                self._group_setting("join_keyword_match_mode", group_umo, "包含匹配"),
            )
        except (ValueError, TimeoutError):
            logger.exception("[%s] 入群正则无效或匹配超时，转交人工审批", PLUGIN_NAME)
            return False
        if approve is None:
            return False
        group_id = str(item.get("group_openid") or "")
        member_id = str(item.get("member_openid") or "")
        request_id = str(item.get("join_request_id") or "")
        if not member_id or not request_id:
            return False
        request_key = (platform_id, group_id, request_id)
        if request_key in self._reviews_inflight:
            return True
        self._reviews_inflight.add(request_key)
        try:
            try:
                await QQGroupManageAPI(client).review_join_request(
                    group_id, member_id, request_id, approve=approve
                )
            except Exception:
                logger.exception(
                    "[%s] 入群关键词审批失败，保留人工审批流程", PLUGIN_NAME
                )
                return False
            self._record_reviewed_request(*request_key)
            return True
        finally:
            self._reviews_inflight.discard(request_key)

    def _record_reviewed_request(
        self, platform_id: str, group_openid: str, join_request_id: str
    ) -> None:
        try:
            self.storage.remove_reviewed_request(
                platform_id, group_openid, join_request_id
            )
        except Exception:
            logger.exception("[%s] 审批已完成，但保存完成记录失败", PLUGIN_NAME)

    def _callback_admin_ids(self, platform_id: str, group_openid: str) -> list[str]:
        config = self.context.get_config(self._group_umo(platform_id, group_openid))
        return sorted(
            {
                str(user_id)
                for user_id in (
                    *config.get("admins_id", []),
                    *self.storage.group_admins(group_openid),
                )
                if str(user_id)
            }
        )

    async def _handle_panel_interaction(self, platform_id: str, interaction: Any) -> bool:
        """Handle qqpanel:* callbacks from the group panel."""
        resolved = getattr(getattr(interaction, "data", None), "resolved", None)
        data = str(getattr(resolved, "button_data", "") or "")
        match = parse_button(data)
        if match is None:
            return False
        platform = self.context.get_platform_inst(platform_id)
        if platform is None:
            return True
        api = QQGroupManageAPI(platform.client)
        interaction_id = str(getattr(interaction, "id", "") or "")
        if not interaction_id:
            return True

        async def acknowledge(code: int) -> None:
            try:
                await asyncio.wait_for(
                    api.acknowledge_interaction(interaction_id, code), 3
                )
            except Exception:
                logger.exception("[%s] 回应群管面板按钮失败", PLUGIN_NAME)

        group = str(getattr(interaction, "group_openid", "") or "")
        sender = str(getattr(interaction, "group_member_openid", "") or "")
        if (
            not group
            or not sender
            or getattr(interaction, "type", None) != 11
            or getattr(interaction, "chat_type", None) != 1
        ):
            await acknowledge(4)
            return True
        action, value = match.group(1), match.group(2)
        event_id = str(getattr(interaction, "event_id", "") or interaction_id)
        if action == "noop":
            await acknowledge(0)
            return True
        if action == "manage":
            await acknowledge(0)
            await self._send_manage_panel(platform_id, api, group, event_id)
            return True
        if action == "group_help":
            await acknowledge(0)
            await self._send_group_help(platform_id, api, group, event_id)
            return True
        if action == "status":
            await acknowledge(0)
            if not await self._send_server_status_image(api, group):
                await self._send_panel_text(
                    api, group, "服务器状态图片生成失败，请稍后重试。", event_id
                )
            return True
        if action in PANEL_IMAGE_KEYS:
            await acknowledge(0)
            await self._send_panel_image(api, group, action, event_id)
            return True
        if action in {"audit", "verify", "keyword", "qr", "link"} and value in {
            "on",
            "off",
        }:
            allowed = await self.verifier._admin_role_ok(api, group, sender)
            if allowed is False:
                await acknowledge(5)
                await self._send_panel_text(
                    api, group, "只有 QQ 群主或群管理员可以修改群管面板开关。", event_id
                )
                return True
            if allowed is None:
                # 群成员信息接口是白名单接口；查询失败时依赖 QQ 客户端对
                # permission.type=1 按钮的身份校验，避免误伤真正的群主。
                logger.warning(
                    "[%s] 群成员角色查询失败，按 QQ 客户端管理员按钮权限继续",
                    PLUGIN_NAME,
                )
            enabled = value == "on"
            umo = self._group_umo(platform_id, group)
            if action == "audit":
                self._set_feature_for_umo(umo, "enable_join_notice", enabled)
                self._set_feature_for_umo(umo, "enable_join_reply_review", enabled)
            elif action == "verify":
                self._set_feature_for_umo(umo, "enable_join_verify", enabled)
            else:
                feature = {
                    "keyword": "enable_keyword_recall",
                    "qr": "enable_qr_recall",
                    "link": "enable_link_recall",
                }[action]
                self._set_feature_for_umo(umo, feature, enabled)
            await acknowledge(0)
            await self._send_manage_panel(platform_id, api, group, event_id)
            return True
        await acknowledge(4)
        return True

    def _set_feature_for_umo(self, umo: str, key: str, value: bool) -> None:
        section = CONFIG_SECTIONS[key]
        global_value = bool(self._config(key, False))
        GroupConfig(self.config).apply_panel_override(
            umo,
            section,
            key,
            bool(value),
            global_value,
        )

    async def _send_panel_text(
        self, api: QQGroupManageAPI, group: str, text: str, event_id: str = ""
    ) -> None:
        try:
            await asyncio.wait_for(
                api.send_group_text(group, text, event_id=event_id), 10
            )
        except Exception:
            logger.exception("[%s] 发送群管面板提示失败", PLUGIN_NAME)

    async def _send_panel_image(
        self, api: QQGroupManageAPI, group: str, key: str, event_id: str
    ) -> None:
        image = load_image(self.storage, key)
        if image is None:
            await self._send_panel_text(
                api,
                group,
                f"还没有上传「{PANEL_IMAGE_KEYS.get(key, key)}」图片，请先到 WebUI → 数据页上传。",
                event_id,
            )
            return
        raw, mime, name = image
        try:
            uploaded = await asyncio.wait_for(
                api.upload_group_image(
                    group,
                    name,
                    base64.b64encode(raw).decode("ascii"),
                ),
                20,
            )
            file_info = (
                str(uploaded.get("file_info") or "")
                if isinstance(uploaded, dict)
                else ""
            )
            if not file_info:
                raise RuntimeError("上传接口没有返回 file_info")
            await asyncio.wait_for(api.send_group_media(group, file_info), 15)
        except Exception:
            logger.exception("[%s] 发送群管面板图片失败", PLUGIN_NAME)
            await self._send_panel_text(api, group, "图片发送失败，请稍后重试。", event_id)

    async def _send_group_help(
        self,
        platform_id: str,
        api: QQGroupManageAPI,
        group: str,
        event_id: str,
    ) -> None:
        text = self._group_admin_help_text(platform_id, group)
        if not text:
            await self._send_panel_text(api, group, "群管帮助指令已关闭。", event_id)
            return
        try:
            path = await self.text_to_image(
                text,
                return_url=False,
                umo=self._group_umo(platform_id, group),
            )
            raw = Path(str(path).removeprefix("file://")).read_bytes()
            uploaded = await asyncio.wait_for(
                api.upload_group_image(
                    group,
                    "group-help.png",
                    base64.b64encode(raw).decode("ascii"),
                ),
                20,
            )
            file_info = (
                str(uploaded.get("file_info") or "")
                if isinstance(uploaded, dict)
                else ""
            )
            if not file_info:
                raise RuntimeError("上传接口没有返回 file_info")
            await asyncio.wait_for(api.send_group_media(group, file_info), 15)
        except Exception:
            logger.warning(
                "[%s] 群管帮助图片生成/发送失败，降级为文字",
                PLUGIN_NAME,
                exc_info=True,
            )
            await self._send_panel_text(api, group, text, event_id)

    async def _send_server_status_image(
        self, api: QQGroupManageAPI, group: str
    ) -> bool:
        try:
            raw = await asyncio.to_thread(self.server_status.render_card)
            if not raw:
                return False
            uploaded = await asyncio.wait_for(
                api.upload_group_image(
                    group,
                    "server-status.png",
                    base64.b64encode(raw).decode("ascii"),
                ),
                20,
            )
            file_info = (
                str(uploaded.get("file_info") or "")
                if isinstance(uploaded, dict)
                else ""
            )
            if not file_info:
                raise RuntimeError("上传接口没有返回 file_info")
            await asyncio.wait_for(api.send_group_media(group, file_info), 15)
            return True
        except Exception:
            logger.exception("[%s] 发送服务器状态图片失败", PLUGIN_NAME)
            return False

    def _write_status_image(self, raw: bytes) -> Path | None:
        """把渲染好的状态 PNG 写入插件数据目录，供通用消息链发送。"""
        try:
            cache = self.server_status.data_dir / "cache"
            cache.mkdir(parents=True, exist_ok=True)
            path = cache / "server-status.png"
            path.write_bytes(raw)
            return path
        except Exception:
            logger.exception("[%s] 保存服务器状态图片失败", PLUGIN_NAME)
            return None

    async def _status_text_message(self, is_qq: bool) -> str:
        """生成服务器状态的文字摘要；QQ 平台额外展示 QQ 专属信息。"""
        try:
            data = await asyncio.to_thread(self.server_status.overview)
            if not data.get("ok"):
                return str(data.get("error") or "服务器状态采集失败")
            memory = data.get("memory") or {}
            disk = data.get("disk") or {}
            network = data.get("network") or {}
            lines = [
                "服务器运行状态",
                f"CPU：{float(data.get('cpu') or 0):.1f}%",
                f"内存：{float(memory.get('percent') or 0):.1f}%"
                f"（{memory.get('text') or '--'}）",
                f"磁盘：{float(disk.get('percent') or 0):.1f}%"
                f"（{disk.get('text') or '--'}）",
                f"网络：↓ {network.get('down_text') or '--'} / ↑ {network.get('up_text') or '--'}",
            ]
            if is_qq:
                lines.append(
                    "官方平台："
                    f"{'在线' if data.get('bot', {}).get('online') else '离线'}"
                )
                lines.append(f"已知群聊：{data.get('known_groups', 0)}")
            lines.append(f"采样间隔：{data.get('sample_seconds', '--')} 秒")
            return "\n".join(lines)
        except Exception as exc:
            return f"读取服务器状态失败：{exc}"

    def _group_admin_help_text(self, platform_id: str, group: str) -> str:
        umo = self._group_umo(platform_id, group)
        if not bool(self._group_setting("enable_group_admin_commands", umo, True)):
            return ""
        default_duration = str(
            self._group_setting("default_mute_duration", umo, "1分") or "1分"
        )
        return format_group_admin_help(default_duration)

    async def _send_manage_panel(
        self, platform_id: str, api: QQGroupManageAPI, group: str, event_id: str = ""
    ) -> None:
        umo = self._group_umo(platform_id, group)
        audit = bool(self._group_setting("enable_join_reply_review", umo, False))
        verify = bool(self._group_setting("enable_join_verify", umo, False))
        keyword = bool(self._group_setting("enable_keyword_recall", umo, False))
        qr = bool(self._group_setting("enable_qr_recall", umo, False))
        link = bool(self._group_setting("enable_link_recall", umo, False))
        try:
            group_uid = self.storage.ensure_group_uid(umo)
        except Exception:
            logger.exception("[%s] 分配群 UID 失败", PLUGIN_NAME)
            group_uid = ""
        content = (
            "🧰群管面板🧰\n"
            f"入群审核申请：{'已开启' if audit else '已关闭'}\n"
            f"入群人机验证：{'已开启' if verify else '已关闭'}\n"
            f"违禁词撤回：{'已开启' if keyword else '已关闭'}\n"
            f"二维码撤回：{'已开启' if qr else '已关闭'}\n"
            f"链接撤回：{'已开启' if link else '已关闭'}\n"
            f"群聊UID：{group_uid or group}"
        )
        try:
            await asyncio.wait_for(
                api.send_group_markdown(
                    group,
                    content,
                    event_id=event_id,
                    keyboard=manage_keyboard(group),
                ),
                15,
            )
        except Exception:
            logger.exception("[%s] 发送群管面板失败", PLUGIN_NAME)

    async def _handle_review_interaction(
        self, platform_id: str, interaction: Any
    ) -> bool:
        """Consume our callbacks and authorize the clicker, including on old buttons."""
        resolved = getattr(getattr(interaction, "data", None), "resolved", None)
        data = str(getattr(resolved, "button_data", "") or "")
        if not data.startswith("qqga:"):
            return False
        platform = self.context.get_platform_inst(platform_id)
        if platform is None:
            return True
        api = QQGroupManageAPI(platform.client)
        interaction_id = str(getattr(interaction, "id", "") or "")
        if not interaction_id:
            return True

        async def acknowledge(code: int) -> None:
            try:
                # ACK is independent of the potentially slower approval request.
                await asyncio.wait_for(
                    api.acknowledge_interaction(interaction_id, code), 3
                )
            except Exception:
                if self._callback_guard.should_log_error("ack"):
                    logger.exception("[%s] 回应审批按钮失败", PLUGIN_NAME)

        match = REVIEW_CALLBACK_RE.fullmatch(data)
        group = str(getattr(interaction, "group_openid", "") or "")
        sender = str(getattr(interaction, "group_member_openid", "") or "")
        if (
            not match
            or not group
            or not sender
            or getattr(interaction, "type", None) != 11
            or getattr(interaction, "chat_type", None) != 1
        ):
            await acknowledge(4)
            return True
        token, action, audience = match.groups()
        if getattr(resolved, "button_id", None) != f"qqga-{action}-{audience}":
            await acknowledge(4)
            return True
        umo = self._group_umo(platform_id, group)
        if not await self._sdk_group_enabled(
            umo, actor_id=sender
        ) or not self._feature_setting("enable_join_reply_review", umo):
            await acknowledge(4)
            return True
        assigned_admin = sender in self._callback_admin_ids(platform_id, group)
        matched = self.storage.find_pending_by_token(token)
        if matched is None:
            await acknowledge(3)  # Completed, expired or from a removed notification.
            return True
        _, pending = matched
        if (
            pending.get("platform_id") != platform_id
            or pending.get("group_openid") != group
        ):
            await acknowledge(4)
            return True
        callbacks = pending.get("review_callbacks")
        native_button = False
        if callbacks is not None:
            # Bind BOTH operation and audience to an independently generated token.
            # A legacy token or an edited assigned button cannot become native.
            if callbacks.get(token) != {"action": action, "audience": audience}:
                await acknowledge(4)
                return True
            native_button = audience == "native"
            if not native_button and not assigned_admin:
                await acknowledge(5)
                return True
        denial = self._callback_guard.check_click(
            platform_id,
            group,
            sender,
            assigned_admin=assigned_admin or native_button,
        )
        if denial is not None:
            await acknowledge(denial)
            return True
        request_key = (platform_id, group, str(pending["join_request_id"]))
        if request_key in self._reviews_inflight:
            await acknowledge(2)
            return True
        self._reviews_inflight.add(request_key)
        try:
            if not assigned_admin and not native_button:
                # Legacy notifications retain live role verification. New native
                # buttons rely on QQ enforcing permission.type=1 before dispatch.
                if not self._callback_guard.start_lookup():
                    await acknowledge(2)
                    return True
                try:
                    member = await asyncio.wait_for(
                        api.get_group_member_info(group, sender), 2
                    )
                except Exception:
                    if self._callback_guard.should_log_error("lookup"):
                        logger.exception(
                            "[%s] 无法验证按钮点击者身份，请检查获取群成员信息接口权限",
                            PLUGIN_NAME,
                        )
                    await acknowledge(1)
                    return True
                finally:
                    self._callback_guard.finish_lookup()
                if (
                    not isinstance(member, dict)
                    or member.get("member_openid") != sender
                    or member.get("member_role") not in {"owner", "admin"}
                ):
                    self._callback_guard.remember_denied(platform_id, group, sender)
                    await acknowledge(4)
                    return True
            # A quoted reply may have resolved the request during the role lookup.
            if self.storage.find_pending_by_token(token) is None:
                await acknowledge(3)
                return True
            await acknowledge(0)
            try:
                await api.review_join_request(
                    group,
                    str(pending["member_openid"]),
                    str(pending["join_request_id"]),
                    approve=action == "approve",
                )
            except Exception:
                logger.exception("[%s] 按钮审批入群申请失败", PLUGIN_NAME)
                result = "入群申请审批失败\n该申请可能已被其他管理员处理"
            else:
                self._record_reviewed_request(*request_key)
                result = (
                    "已同意入群申请。" if action == "approve" else "已拒绝入群申请。"
                )
            try:
                await api.send_group_text(
                    group,
                    result,
                    event_id=str(
                        getattr(interaction, "event_id", "") or interaction_id
                    ),
                )
            except Exception:
                # The approval may already have succeeded; never repeat it for a send failure.
                logger.exception("[%s] 发送按钮审批结果失败", PLUGIN_NAME)
        finally:
            self._reviews_inflight.discard(request_key)
        return True

    @filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE, priority=0)
    async def remember_group_activity(self, event: AstrMessageEvent) -> None:
        """Remember group_openid for the WebUI group list; never stores content."""
        if not self._is_qq_group(event):
            # 钉钉群消息也记录，便于在 WebUI 维护分群配置与插件群管名单。
            if (
                event.get_platform_name() != DINGTALK_PLATFORM
                or not event.get_group_id()
            ):
                return
        try:
            self.storage.remember_group(
                event.get_platform_id(),
                self._portable_group_id(event.get_group_id()),
            )
        except Exception:
            logger.exception("[%s] 记录群组活跃信息失败", PLUGIN_NAME)

    @filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE, priority=200)
    async def join_verify_guard(self, event: AstrMessageEvent) -> None:
        # 先于违禁词和引用审批执行：未验证成员的消息只做验证处理。
        await self.verifier.guard(event)

    @filter.command("验证列表")
    async def verify_list_command(self, event: AstrMessageEvent) -> None:
        """查看本群未完成进群验证的成员。"""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return
        yield event.plain_result(self.verifier.listing(event))

    @filter.command("验证放行")
    async def verify_release_command(self, event: AstrMessageEvent) -> None:
        """放行被艾特成员的进群验证，验证失败的成员会同时解除禁言。"""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return
        targets = self._mentioned_members(event)
        if not targets:
            yield event.plain_result("请艾特要放行的成员，例如：验证放行 @用户")
            return
        yield event.plain_result(await self.verifier.release(event, targets))

    @filter.command("重新验证")
    async def verify_restart_command(self, event: AstrMessageEvent) -> None:
        """让被艾特的成员重新进行进群验证。"""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return
        targets = self._mentioned_members(event)
        if not targets:
            yield event.plain_result("请艾特要重新验证的成员，例如：重新验证 @用户")
            return
        yield event.plain_result(await self.verifier.restart(event, targets))

    @filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE, priority=100)
    async def keyword_mute(self, event: AstrMessageEvent) -> None:
        if not self._is_qq_group(event):
            return
        recall_enabled = self._event_feature_setting(
            event, "enable_keyword_recall", False
        )
        if not recall_enabled:
            return
        sender = event.get_sender_id()
        if not sender or sender == event.get_self_id():
            return
        if (
            event.is_at_or_wake_command
            and re.match(r"^群管功能(?:\s|$)", event.get_message_str().strip())
            and self._can_manage(event)
        ):
            return
        text = "".join(
            part.text for part in event.get_messages() if isinstance(part, Plain)
        )
        if not self.lexicons.match(text):
            return
        if not await self._sdk_group_enabled(self._event_group_umo(event)):
            return
        quote = review_quote(event)
        if (
            quote
            and self._can_manage(event)
            and self._event_feature_setting(event, "enable_join_reply_review")
            and self._review_action_match(event) is not None
            and self.storage.find_pending_by_quote(
                quote, event.get_platform_id(), event.get_group_id()
            )
            is not None
        ):
            # Only a real, authorized review takes precedence over the word filter.
            await self.reply_review(event)
            return
        event.stop_event()
        message_id = getattr(event.message_obj, "message_id", "")
        try:
            # Never use a quoted message ID or a session's last message ID.
            if not message_id:
                raise ValueError("当前消息缺少消息 ID，无法撤回")
            api = QQGroupManageAPI(self._platform(event).client)
            await asyncio.wait_for(
                api.recall_group_message(event.get_group_id(), str(message_id)),
                timeout=10,
            )
        except Exception:
            logger.exception("[%s] 违禁词消息撤回失败", PLUGIN_NAME)
            return
        notice = str(
            self._event_setting(event, "keyword_recall_notice", "") or ""
        ).strip()
        if not notice:
            return
        try:
            await asyncio.wait_for(
                api.send_group_text(
                    event.get_group_id(), notice, msg_id=str(message_id)
                ),
                timeout=10,
            )
        except Exception:
            logger.exception("[%s] 违禁词撤回提醒发送失败", PLUGIN_NAME)

    @filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE, priority=150)
    async def link_recall(self, event: AstrMessageEvent) -> None:
        """撤回文字中包含链接或图片中的二维码。"""
        if not self._is_qq_group(event):
            return
        link_enabled = self._event_feature_setting(event, "enable_link_recall", False)
        qr_enabled = self._event_feature_setting(event, "enable_qr_recall", False)
        if not link_enabled and not qr_enabled:
            return
        sender = event.get_sender_id()
        if not sender or sender == event.get_self_id():
            return
        if self._can_manage(event):
            return
        text = "".join(
            part.text for part in event.get_messages() if isinstance(part, Plain)
        )
        link_hit = link_enabled and contains_link(text)
        qr_url = ""
        if not link_hit and qr_enabled:
            qr_url = await self._contains_qr_image(event)
        qr_hit = bool(qr_url)
        if not link_hit and not qr_hit:
            return
        if not await self._sdk_group_enabled(self._event_group_umo(event)):
            return
        event.stop_event()
        message_id = getattr(event.message_obj, "message_id", "")
        try:
            api = QQGroupManageAPI(self._platform(event).client)
            if not message_id:
                raise ValueError("当前消息缺少消息 ID，无法撤回")
            await asyncio.wait_for(
                api.recall_group_message(event.get_group_id(), str(message_id)),
                timeout=10,
            )
        except Exception:
            logger.exception("[%s] 消息撤回失败", PLUGIN_NAME)
            return
        if link_hit:
            match = LINK_PATTERN.search(text)
            recall_kind = "link"
            recall_content = match.group(0) if match else text[:1000]
        else:
            recall_kind = "qr"
            recall_content = qr_url
        try:
            self.recall_monitor.record(
                self._event_group_umo(event),
                event.get_group_id(),
                sender,
                recall_kind,
                recall_content,
                str(message_id),
                time.monotonic(),
            )
        except Exception:
            logger.exception("[%s] 记录风险撤回失败", PLUGIN_NAME)
        notice_key = "link_recall_notice" if link_hit else "qr_recall_notice"
        notice = str(self._event_setting(event, notice_key, "") or "").strip()
        if not notice:
            return
        try:
            await asyncio.wait_for(
                api.send_group_text(
                    event.get_group_id(), notice, msg_id=str(message_id)
                ),
                timeout=10,
            )
        except Exception:
            logger.exception("[%s] 撤回提醒发送失败", PLUGIN_NAME)

    async def _contains_qr_image(self, event: AstrMessageEvent) -> str:
        images = [part for part in event.get_messages() if isinstance(part, Image)]
        if not images:
            return ""
        for part in images[:3]:
            try:
                path = await asyncio.wait_for(part.convert_to_file_path(), timeout=10)
                if await asyncio.to_thread(is_qr_code, path):
                    return str(
                        getattr(part, "url", "")
                        or getattr(part, "file", "")
                        or "二维码图片"
                    )
            except Exception:
                logger.exception("[%s] 二维码图片识别失败", PLUGIN_NAME)
        return ""

    def _spam_limits(self, event: AstrMessageEvent) -> dict[int, int]:
        limits = {
            1: max(0, int(self._event_setting(event, "spam_limit_1s", 5) or 0)),
            60: max(0, int(self._event_setting(event, "spam_limit_1m", 20) or 0)),
            3600: max(0, int(self._event_setting(event, "spam_limit_1h", 0) or 0)),
        }
        if self._event_feature_setting(event, "spam_night_enabled", False):
            hour = datetime.now().hour
            if hour >= 22 or hour < 6:
                night = max(
                    0, int(self._event_setting(event, "spam_night_limit", 0) or 0)
                )
                if night > 0 and (limits[60] <= 0 or night < limits[60]):
                    limits[60] = night
        return limits

    @staticmethod
    def _spam_exceeded(counts: dict[int, int], limits: dict[int, int]) -> str:
        labels = {1: "最近1秒", 60: "最近1分钟", 3600: "最近1小时"}
        for window in (1, 60, 3600):
            limit = limits.get(window, 0)
            if limit > 0 and counts.get(window, 0) > limit:
                return f"{labels[window]}消息数超过 {limit} 条"
        return ""

    @filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE, priority=160)
    async def spam_guard(self, event: AstrMessageEvent) -> None:
        """统计成员消息频率，超限时撤回近期消息并禁言。"""
        if not self._is_qq_group(event):
            return
        if not self._event_feature_setting(event, "enable_anti_spam", False):
            return
        sender = event.get_sender_id()
        if not sender or sender == event.get_self_id():
            return
        if self._can_manage(event):
            return
        group_umo = self._event_group_umo(event)
        if not await self._sdk_group_enabled(group_umo):
            return
        now = time.monotonic()
        message_id = str(getattr(event.message_obj, "message_id", "") or "")
        counts = self.spam_monitor.record(group_umo, sender, message_id, now)
        if self.spam_monitor.in_cooldown(group_umo, sender, now):
            return
        reason = self._spam_exceeded(counts, self._spam_limits(event))
        if not reason:
            return
        try:
            seconds = parse_duration(
                str(self._event_setting(event, "spam_mute_duration", "300秒"))
            )
            self._validate_duration(seconds, group_umo)
            if seconds <= 0:
                raise ValueError("刷屏禁言时长必须大于 0")
        except Exception:
            logger.exception("[%s] 刷屏监控禁言时长无效", PLUGIN_NAME)
            return
        event.stop_event()
        # 先记录处罚状态，避免同一时间窗口内重复撤回与禁言。
        self.spam_monitor.mark_punished(group_umo, sender, now, seconds, reason)
        threshold = max(
            0, int(self._event_setting(event, "spam_recall_threshold", 10) or 0)
        )
        recall_ids = self.spam_monitor.recent_ids(group_umo, sender, threshold)
        platform = self._platform(event)
        if recall_ids and platform is not None:
            api = QQGroupManageAPI(platform.client)
            for recall_id in recall_ids:
                try:
                    await asyncio.wait_for(
                        api.recall_group_message(event.get_group_id(), recall_id),
                        timeout=10,
                    )
                except Exception:
                    logger.exception("[%s] 刷屏消息撤回失败", PLUGIN_NAME)
        try:
            await self._mute(event, event.get_group_id(), sender, seconds)
        except Exception:
            logger.exception("[%s] 刷屏自动禁言失败", PLUGIN_NAME)

    def _review_action_match(self, event: AstrMessageEvent) -> re.Match | None:
        action_text = review_action_text(event)
        action_match = ACTION_RE.fullmatch(action_text)
        if action_match is None:
            config = self.context.get_config(self._event_group_umo(event))
            for prefix in config.get("wake_prefix", []):
                if prefix and action_text.startswith(prefix):
                    action_match = ACTION_RE.fullmatch(
                        action_text[len(prefix) :].strip()
                    )
                    break
        return action_match

    @filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE, priority=10)
    async def reply_review(self, event: AstrMessageEvent) -> None:
        if not self._is_qq_group(event) or not self._event_feature_setting(
            event,
            "enable_join_reply_review",
        ):
            return
        quote = review_quote(event)
        if quote is None:
            return
        action_match = self._review_action_match(event)
        if action_match is None:
            return
        try:
            matched = self.storage.find_pending_by_quote(
                quote, event.get_platform_id(), event.get_group_id()
            )
            if matched is None:
                result = (
                    "这条引用没有提供原消息 ID 或有效引用索引，请使用申请卡片上的审批按钮。"
                    if not quote
                    else "引用索引未唯一匹配到本群待审批申请，可能已处理或过期，请使用申请卡片上的审批按钮。"
                )
            elif not self._can_manage(event):
                result = "你没有本群群管权限。"
            else:
                pending_key, pending = matched
                approve = action_match.group(1) in {"同意", "通过"}
                reason = (action_match.group(2) or "").strip()
                try:
                    await self._review(
                        event,
                        str(pending["group_openid"]),
                        str(pending["member_openid"]),
                        str(pending["join_request_id"]),
                        approve,
                        reason,
                    )
                except Exception as exc:
                    result = f"审批失败：{exc}"
                else:
                    self.storage.remove_pending(pending_key)
                    result = (
                        "已同意入群申请。"
                        if approve
                        else f"已拒绝入群申请。{(' 理由：' + reason) if reason else ''}"
                    )
            # Send before stopping: yielding a result after stop_event can either
            # skip sending or replace the STOP result on older AstrBot versions.
            await event.send(event.plain_result(result))
        finally:
            event.stop_event()

    @filter.command("禁言")
    async def mute_command(self, event: AstrMessageEvent) -> None:
        """禁言被艾特的成员，时间支持 30秒、10分、2小时、1天。"""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._event_feature_setting(event, "enable_mute_command"):
            yield event.plain_result("禁言指令已关闭。")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return
        targets = self._mentioned_members(event)
        if not targets:
            yield event.plain_result("请艾特要禁言的成员，例如：禁言 @用户 [时间]")
            return
        try:
            time = extract_mute_duration(
                event.get_message_str(),
                str(
                    self._event_setting(event, "default_mute_duration", "1分") or "1分"
                ),
            )
            seconds = parse_duration(time)
            self._validate_duration(seconds, self._event_group_umo(event))
        except Exception as exc:
            yield event.plain_result(f"禁言失败：{exc}")
            return
        failure = await self._mute_members(event, targets, seconds)
        if failure:
            yield event.plain_result(failure)
            return
        if self._event_feature_setting(
            event,
            "silent_mute_success_notice",
            False,
        ):
            return
        if seconds == 0:
            yield event.plain_result(f"已解除 {len(targets)} 名成员的禁言。")
        else:
            yield event.plain_result(f"已禁言 {len(targets)} 名成员，时长 {time}。")

    @filter.command("解禁")
    async def unmute_command(self, event: AstrMessageEvent) -> None:
        """解除被艾特成员的禁言。"""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._event_feature_setting(event, "enable_mute_command"):
            yield event.plain_result("禁言指令已关闭。")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return
        targets = self._mentioned_members(event)
        if not targets:
            yield event.plain_result("请艾特要解除禁言的成员，例如：解禁 @用户")
            return
        failure = await self._mute_members(event, targets, 0)
        if failure:
            yield event.plain_result(failure)
            return
        if self._event_feature_setting(
            event,
            "silent_mute_success_notice",
            False,
        ):
            return
        yield event.plain_result(f"已解除 {len(targets)} 名成员的禁言。")

    @filter.command("踢人")
    async def kick_members_command(self, event: AstrMessageEvent) -> None:
        """批量移出被艾特的群成员（QQ 官方接口，单次最多 20 人）。"""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._event_feature_setting(event, "enable_group_admin_commands"):
            yield event.plain_result("群管基础指令已关闭。")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return
        targets = self._mentioned_members(event, limit=20)
        if not targets:
            yield event.plain_result("请艾特要移出的群成员，例如：踢人 @用户")
            return
        platform = self._platform(event)
        if platform is None or getattr(platform, "client", None) is None:
            yield event.plain_result("对应的 QQ 平台当前不在线。")
            return
        try:
            result = await asyncio.wait_for(
                QQGroupManageAPI(platform.client).batch_remove_members(
                    event.get_group_id(),
                    targets,
                ),
                timeout=20,
            )
        except asyncio.TimeoutError:
            yield event.plain_result("踢人请求超时，请稍后刷新群成员确认结果。")
            return
        except Exception as exc:
            logger.exception("[%s] 批量移出群成员失败", PLUGIN_NAME)
            detail = str(exc)
            if "11253" in detail:
                yield event.plain_result(
                    "踢人失败：QQ 接口无访问权限（11253），请确认机器人有群成员移除权限。"
                )
            else:
                yield event.plain_result(f"踢人失败：{detail[:200]}")
            return
        if isinstance(result, dict) and str(
            result.get("remove_members_result") or ""
        ).lower() not in {"", "success"}:
            yield event.plain_result(
                f"踢人失败：接口返回 {result.get('remove_members_result')}"
            )
            return
        blacklist_failed = (
            result.get("add_to_member_blacklist_fail_openids")
            if isinstance(result, dict)
            else None
        )
        message = f"已移出 {len(targets)} 名群成员。"
        if isinstance(blacklist_failed, list) and blacklist_failed:
            message += f"（{len(blacklist_failed)} 名加入黑名单失败）"
        yield event.plain_result(message)

    @filter.command("添加群管")
    async def add_group_admin(self, event: AstrMessageEvent) -> None:
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._event_feature_setting(event, "enable_group_admin_commands"):
            return
        if not self._can_manage_plugin_admins(event):
            yield event.plain_result(
                "只有 AstrBot 管理员能添加插件群管；也可在配置中授权 QQ 群主或群管理员。"
            )
            return
        targets = self._mentioned_members(event)
        if not targets:
            yield event.plain_result("请艾特要添加的群管。")
            return
        try:
            added = self.storage.update_group_admins(
                event.get_group_id(), targets, add=True
            )
        except OSError:
            logger.exception("[%s] 保存群管名单失败", PLUGIN_NAME)
            yield event.plain_result(
                "群管名单保存失败，本次修改未生效，请检查存储权限和磁盘空间。"
            )
            return
        yield event.plain_result(f"已添加 {added} 名本群群管。")

    @filter.command("删除群管", alias={"移除群管"})
    async def remove_group_admin(self, event: AstrMessageEvent) -> None:
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._event_feature_setting(event, "enable_group_admin_commands"):
            return
        if not self._can_manage_plugin_admins(event):
            yield event.plain_result(
                "只有 AstrBot 管理员能删除插件群管；也可在配置中授权 QQ 群主或群管理员。"
            )
            return
        targets = self._mentioned_members(event)
        if not targets:
            yield event.plain_result("请艾特要删除的群管。")
            return
        try:
            removed = self.storage.update_group_admins(
                event.get_group_id(), targets, add=False
            )
        except OSError:
            logger.exception("[%s] 保存群管名单失败", PLUGIN_NAME)
            yield event.plain_result(
                "群管名单保存失败，本次修改未生效，请检查存储权限和磁盘空间。"
            )
            return
        yield event.plain_result(f"已删除 {removed} 名本群群管。")

    @filter.command("群绑定")
    async def bind_group_note(
        self,
        event: AstrMessageEvent,
        group_number: str = "",
        group_name: str = "",
    ) -> None:
        """Bind the current group_openid to a human-readable QQ group number."""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._event_feature_setting(event, "enable_group_admin_commands"):
            yield event.plain_result("群管基础指令已关闭。")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return

        number = str(group_number or "").strip()
        name = str(group_name or "").strip()
        # Preserve spaces in the optional group name. AstrBot's command parser
        # only hands us the first token, so read the original text as a fallback.
        raw = event.get_message_str().strip()
        raw = re.sub(r"^.*?群绑定(?:\s+|$)", "", raw, count=1).strip()
        if raw:
            parts = raw.split(maxsplit=1)
            if parts and re.fullmatch(r"\d{5,12}", parts[0]):
                number = parts[0]
                name = parts[1].strip() if len(parts) > 1 else ""

        if not re.fullmatch(r"\d{5,12}", number):
            yield event.plain_result(
                "用法：群绑定 群号 [群名]\n例如：群绑定 123456789 天文社\n"
                "群号只用于控制台备注，不会改变 AstrBot 的 group_openid。"
            )
            return
        note = f"{number} {name}".strip()
        if len(note) > 120:
            yield event.plain_result("群备注不能超过 120 个字符。")
            return
        umo = self._event_group_umo(event)
        try:
            saved = self.storage.set_group_note(umo, note)
        except OSError:
            logger.exception("[%s] 保存群备注失败", PLUGIN_NAME)
            yield event.plain_result(
                "群备注保存失败，本次修改未生效，请检查存储权限和磁盘空间。"
            )
            return
        yield event.plain_result(
            f"已绑定本群备注：{saved}\n\n"
            f"群 UMO：{umo}\n"
            "可在 WebUI → 群组 中查看；备注仅用于显示，不改变群身份。"
        )

    @filter.command("群管列表")
    async def list_group_admins(self, event: AstrMessageEvent) -> None:
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._event_feature_setting(event, "enable_group_admin_commands"):
            return
        admins = self.storage.group_admins(event.get_group_id())
        content = "本群群管：\n" + (
            "\n".join(f"- {item}" for item in admins) if admins else "（暂无）"
        )
        content += (
            "\nAstrBot 管理员拥有全局权限；QQ 群主和群管理员默认拥有本群普通群管权限。"
        )
        yield event.plain_result(content)

    @filter.command("群管帮助")
    async def group_admin_help(self, event: AstrMessageEvent) -> None:
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持已启用的 QQ 官方机器人群聊。")
            return
        text = self._group_admin_help_text(
            event.get_platform_id(), event.get_group_id()
        )
        if not text:
            return
        yield event.plain_result(text).use_markdown(True)

    @filter.command("查看状态", alias={"状态"})
    async def server_status_command(self, event: AstrMessageEvent) -> None:
        """发送服务器运行状态图片，失败时降级为文字摘要。"""
        is_qq = event.get_platform_name() in QQ_PLATFORMS
        if is_qq and not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            event.stop_event()
            return
        service = self.server_status
        config = service.get_config()
        if not config.get("enabled", True):
            yield event.plain_result("服务器运行状态采集已关闭。")
            event.stop_event()
            return
        try:
            raw = await asyncio.to_thread(service.render_card)
            if raw:
                if is_qq:
                    platform = self._platform(event)
                    api = QQGroupManageAPI(platform.client)
                    group = event.get_group_id()
                    uploaded = await asyncio.wait_for(
                        api.upload_group_image(
                            group,
                            "server-status.png",
                            base64.b64encode(raw).decode("ascii"),
                        ),
                        20,
                    )
                    file_info = (
                        str(uploaded.get("file_info") or "")
                        if isinstance(uploaded, dict)
                        else ""
                    )
                    if not file_info:
                        raise RuntimeError("上传接口没有返回 file_info")
                    await asyncio.wait_for(api.send_group_media(group, file_info), 15)
                    event.stop_event()
                    return
                image_path = self._write_status_image(raw)
                if image_path is not None:
                    try:
                        sent = await self.context.send_message(
                            event.unified_msg_origin,
                            event.image_result(str(image_path)),
                        )
                    except Exception:
                        logger.exception(
                            "[%s] 发送服务器状态图片失败，降级为文字", PLUGIN_NAME
                        )
                    else:
                        if sent:
                            event.stop_event()
                            return
                        logger.warning(
                            "[%s] 当前会话没有匹配的平台实例，降级为文字", PLUGIN_NAME
                        )
        except Exception:
            logger.exception("[%s] 发送服务器状态图片失败，降级为文字", PLUGIN_NAME)
        message = await self._status_text_message(is_qq)
        yield event.plain_result(message)
        event.stop_event()

    @filter.command("菜单", alias={"菜单指令", "群管面板"})
    async def group_panel_command(self, event: AstrMessageEvent) -> None:
        platform_name = event.get_platform_name()
        if platform_name in QQ_PLATFORMS:
            if not self._is_qq_group(event):
                yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
                event.stop_event()
                return
            platform = self._platform(event)
            if platform is None or getattr(platform, "client", None) is None:
                yield event.plain_result("当前 QQ 平台不在线，无法打开菜单。")
                event.stop_event()
                return
            try:
                await QQGroupManageAPI(platform.client).send_group_markdown(
                    event.get_group_id(),
                    "## 淼淼菜单\n请点击下方按钮选择功能~",
                    keyboard=main_keyboard(),
                )
            except Exception:
                logger.exception("[%s] 发送淼淼菜单失败", PLUGIN_NAME)
                yield event.plain_result("淼淼菜单发送失败，请稍后重试。")
                event.stop_event()
                return
            event.stop_event()
            return
        if self._portable_buttons_ok(event):
            rows = self._portable_menu_rows(event.unified_msg_origin)
            if rows:
                try:
                    chain = event.chain_result(
                        [Plain("## 淼淼菜单\n请点击下方按钮选择功能~"), *rows]
                    )
                except Exception:
                    logger.exception("[%s] 构建淼淼菜单失败", PLUGIN_NAME)
                    chain = None
                if chain is not None:
                    yield chain
                    event.stop_event()
                    return
        yield event.plain_result(self._portable_text_menu())
        event.stop_event()

    # ------------------------------------------------------------------
    # 跨平台按钮（AstrBot >= 4.29.4，当前适配钉钉互动卡片）
    # ------------------------------------------------------------------
    @staticmethod
    def _portable_buttons_ok(event: AstrMessageEvent) -> bool:
        """当前会话能否使用跨平台按钮（已验证钉钉互动卡片适配）。"""
        return _PORTABLE_BUTTONS and event.get_platform_name() == DINGTALK_PLATFORM

    @staticmethod
    def _portable_group_id(group_id: Any) -> str:
        """剥掉钉钉卡片回调 spaceId 可能携带的 openSpaceId 前缀。"""
        group = str(group_id or "")
        if group.startswith(DINGTALK_CARD_GROUP_PREFIX):
            return group[len(DINGTALK_CARD_GROUP_PREFIX) :]
        return group

    @staticmethod
    def _portable_text_menu() -> str:
        return (
            "淼淼菜单（当前平台暂不支持按钮菜单）\n"
            "· 查看状态 / 状态：查看服务器运行状态"
        )

    @staticmethod
    def _portable_menu_rows(umo: str) -> list[Any]:
        """菜单按钮；data 携带发送时会话，点击时据此回复到正确的群/私聊。"""
        menu = (
            ("功能列表", "features", Button.Style.DEFAULT),
            ("使用指南", "guide", Button.Style.DEFAULT),
            ("群管面板", "manage", Button.Style.PRIMARY),
            ("群管帮助", "group_help", Button.Style.DEFAULT),
            ("运行状态", "status", Button.Style.DEFAULT),
            ("获取帮助", "help", Button.Style.DEFAULT),
        )
        rows: list[Any] = []
        for index in range(0, len(menu), 2):
            buttons = [
                Button(
                    id=f"qqga-{token}",
                    label=label,
                    action=Button.CallbackAction(data={"act": token, "umo": umo}),
                    style=style,
                )
                for label, token, style in menu[index : index + 2]
            ]
            rows.append(ActionRow(buttons=buttons))
        return rows

    @_optional_button_action()
    async def portable_button_action(self, event: AstrMessageEvent) -> None:
        """处理 qqga-* 跨平台按钮点击；QQ 官方按钮仍走原生键盘回调。"""
        interaction = event.get_button_interaction()
        if interaction is None:
            return
        if event.get_platform_name() in QQ_PLATFORMS:
            return
        action_id = str(getattr(interaction, "action_id", "") or "")
        if not action_id.startswith("qqga-"):
            return
        data = getattr(interaction, "data", None)
        data = data if isinstance(data, dict) else {}
        act = str(data.get("act") or "").strip() or action_id.removeprefix("qqga-")

        # 回复目标优先取按钮 data 携带的会话：钉钉卡片回调报文缺少可靠的
        # spaceType/spaceId（SDK 也不解析这两个字段），适配器可能把群聊点击
        # 误判为私聊，跟随事件会话回复会错误地发到点击者私聊。
        umo = str(data.get("umo") or "").strip() or event.unified_msg_origin
        logger.info("[%s] 跨平台按钮 %s 回复目标：%s", PLUGIN_NAME, act, umo)
        try:
            await self._handle_portable_action(act, umo)
        except Exception:
            logger.exception("[%s] 处理跨平台按钮点击失败", PLUGIN_NAME)
        event.stop_event()

    async def _handle_portable_action(self, act: str, umo: str) -> None:
        if act in PANEL_IMAGE_KEYS:
            image = load_image(self.storage, act)
            if image is None:
                await self._portable_send_text(
                    umo,
                    f"还没有上传「{PANEL_IMAGE_KEYS.get(act, act)}」图片，"
                    "请先到 WebUI → 数据页上传。",
                )
                return
            raw, _mime, _name = image
            await self._portable_send_image(
                umo, base64.b64encode(raw).decode("ascii")
            )
            return
        if act == "group_help":
            text = self._portable_group_help_text(umo)
            if not text:
                await self._portable_send_text(umo, "群管帮助指令已关闭。")
                return
            try:
                path = await self.text_to_image(text, return_url=False, umo=umo)
                raw = Path(str(path).removeprefix("file://")).read_bytes()
                if await self._portable_send_image(
                    umo, base64.b64encode(raw).decode("ascii")
                ):
                    return
            except Exception:
                logger.warning(
                    "[%s] 跨平台群管帮助图片生成/发送失败，降级为文字",
                    PLUGIN_NAME,
                    exc_info=True,
                )
            await self._portable_send_text(umo, text)
            return
        if act == "status":
            raw = await asyncio.to_thread(self.server_status.render_card)
            if raw and await self._portable_send_image(
                umo, base64.b64encode(raw).decode("ascii")
            ):
                return
            await self._portable_send_text(
                umo, await self._status_text_message(is_qq=False)
            )
            return
        if act == "manage" or act in {
            "audit_on",
            "audit_off",
            "verify_on",
            "verify_off",
        }:
            # 群管面板和开关只在 QQ 官方群有实际作用，其他平台直接提示不支持。
            await self._portable_send_text(umo, "此平台不支持群管面板。")
            return
        await self._portable_send_text(umo, "按钮已失效，请重新发送 菜单 打开面板。")

    def _portable_group_help_text(self, umo: str) -> str:
        if not bool(self._group_setting("enable_group_admin_commands", umo, True)):
            return ""
        default_duration = str(
            self._group_setting("default_mute_duration", umo, "1分") or "1分"
        )
        return format_group_admin_help(default_duration)

    async def _portable_send_chain(self, umo: str, chain: Any) -> bool:
        try:
            sent = await self.context.send_message(umo, chain)
        except Exception:
            logger.exception("[%s] 跨平台按钮回复发送失败", PLUGIN_NAME)
            return False
        if not sent:
            logger.warning(
                "[%s] 跨平台按钮回复未找到平台会话：%s", PLUGIN_NAME, umo
            )
        return bool(sent)

    async def _portable_send_text(self, umo: str, text: str) -> bool:
        return await self._portable_send_chain(umo, MessageEventResult(chain=[Plain(text)]))

    async def _portable_send_image(self, umo: str, image_base64: str) -> bool:
        try:
            chain = MessageEventResult(
                chain=[Image.fromBase64(image_base64)]
            )
        except Exception:
            logger.exception("[%s] 构建跨平台图片消息失败", PLUGIN_NAME)
            return False
        return await self._portable_send_chain(umo, chain)

    @filter.command("群管功能")
    async def group_feature_settings(
        self,
        event: AstrMessageEvent,
        feature_name: str = "",
        action: str = "",
        value: str = "",
    ) -> None:
        """查看或修改当前群的独立功能开关。"""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持已启用的 QQ 官方机器人群聊。")
            return
        per_group = bool(self._config("enable_per_group_feature_settings", False))
        changing = bool(feature_name or action) and not (
            (feature_name in WORD_LISTS or feature_name in KEYWORD_VALUES)
            and action in {"", "查看"}
        )
        if not per_group and changing and not self._is_astr_admin(event):
            yield event.plain_result("你没有权限更改配置项，别乱动人家的功能啊！")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return

        if feature_name in WORD_LISTS or feature_name in KEYWORD_VALUES:
            # AstrBot's older command parser splits string args on spaces. Read the
            # remaining original text so one phrase stays one word-list entry.
            parts = event.get_message_str().strip().split(maxsplit=3)
            if parts and parts[0] == "群管功能" and len(parts) == 4:
                value = parts[3]
            try:
                result = self._keyword_config_command(
                    event, feature_name, action, value
                )
            except (ValueError, OSError) as exc:
                yield event.plain_result(f"配置未修改：{exc}")
                return
            yield event.plain_result(result).use_markdown(True)
            return

        if feature_name or action:
            feature = FEATURES_BY_NAME.get(feature_name.strip())
            if feature is None:
                available = "、".join(
                    [*(item.name for item in FEATURES), *WORD_LISTS, *KEYWORD_VALUES]
                )
                yield event.plain_result(f"未知功能。可用功能：{available}")
                return
            normalized_action = action.strip()
            if normalized_action in {"开启", "打开", "启用", "开"}:
                enabled = True
            elif normalized_action in {"关闭", "停用", "关"}:
                enabled = False
            else:
                yield event.plain_result(
                    f"用法：群管功能 {feature.name} 开启（或关闭）"
                )
                return
            raw_value = not enabled if feature.inverted else enabled
            try:
                self._save_setting(event, feature.key, raw_value)
            except Exception as exc:
                yield event.plain_result(f"保存功能开关失败：{exc}")
                return
            yield event.plain_result(
                f"{feature.name}已{'开启' if enabled else '关闭'}。"
            )
            return

        values: dict[str, bool] = {}
        group_umo = self._event_group_umo(event) if per_group else ""
        for feature in FEATURES:
            raw_value = self._feature_setting(
                feature.key,
                group_umo,
                feature.default,
            )
            values[feature.name] = not raw_value if feature.inverted else raw_value
        yield event.plain_result(
            format_feature_status(values, per_group=per_group)
            + "\n\n群 UMO：`"
            + self._event_group_umo(event)
            + "`"
            + keyword_summary(
                {
                    **{
                        key: self._event_setting(event, key, [])
                        for key in WORD_LISTS.values()
                    },
                    "join_keyword_priority": self._event_setting(
                        event, "join_keyword_priority", "黑词优先"
                    ),
                    "join_keyword_match_mode": self._event_setting(
                        event, "join_keyword_match_mode", "包含匹配"
                    ),
                }
            )
            + verify_summary(self._event_setting(event, "verify_mode", "算术题"))
        ).use_markdown(True)

    def _save_setting(self, event: AstrMessageEvent, key: str, value: Any) -> None:
        if self._config("enable_per_group_feature_settings", False):
            GroupConfig(self.config).set_value(
                self._event_group_umo(event), CONFIG_SECTIONS[key], key, value
            )
        else:
            self._set_config(key, value)

    def _keyword_config_command(
        self, event: AstrMessageEvent, name: str, action: str, value: str
    ) -> str:
        value = value.strip()
        mode = self._event_setting(event, "join_keyword_match_mode", "包含匹配")
        if name in WORD_LISTS:
            key = WORD_LISTS[name]
            regex_mode = key in JOIN_REGEX_KEYS and mode == "正则匹配"
            words = list(self._event_setting(event, key, []))
            if action in {"", "查看"}:
                return word_page(name, words, int(value or "1"), mode)
            if action == "清空":
                if value != "确认":
                    raise ValueError(f"清空需发送：群管功能 {name} 清空 确认")
                words = []
            elif action in {"添加", "删除"}:
                if not value:
                    raise ValueError(f"用法：群管功能 {name} {action} 词条")
                # Regex escapes are case-sensitive: \D and \d must remain distinct.
                normalize = str.strip if regex_mode else lambda s: s.strip().casefold()
                normalized = [normalize(word) for word in words]
                if action == "添加":
                    if regex_mode:
                        compile_join_pattern(value)
                    if normalize(value) in normalized:
                        return "该词条已存在。"
                    words.append(value)
                elif normalize(value) in normalized:
                    words = [
                        word for word in words if normalize(word) != normalize(value)
                    ]
                else:
                    raise ValueError("词条不存在，请先查看列表")
            else:
                raise ValueError("支持：查看、添加、删除、清空 确认")
            self._save_setting(event, key, words)
            return f"{name}已保存，当前 {len(words)} 条。"
        key = KEYWORD_VALUES[name]
        if action in {"", "查看"}:
            current = (
                mode
                if key == "join_keyword_match_mode"
                else self._event_setting(event, key)
            )
            return f"{name}：{current}"
        if action != "设置":
            raise ValueError(f"用法：群管功能 {name} 设置 内容")
        if key == "join_keyword_priority":
            if value not in {"白词优先", "黑词优先"}:
                raise ValueError("请选择 白词优先 或 黑词优先")
        elif key == "verify_mode":
            if value not in VERIFY_MODES:
                raise ValueError("请选择 " + " 或 ".join(VERIFY_MODES))
        elif key == "join_keyword_match_mode":
            if value not in {"包含匹配", "正则匹配"}:
                raise ValueError("请选择 包含匹配 或 正则匹配")
            if value == "正则匹配":
                for word_key in JOIN_REGEX_KEYS:
                    for word in self._event_setting(event, word_key, []):
                        if word.strip():
                            compile_join_pattern(word.strip())
        self._save_setting(event, key, value)
        return f"{name}已保存。"

    @filter.command("禁言状态")
    async def mute_status_command(self, event: AstrMessageEvent) -> None:
        """查看全员禁言规则和当前处于禁言中的成员。"""
        if not self._is_qq_group(event):
            yield event.plain_result("该指令仅支持 QQ 官方机器人群聊。")
            return
        if not self._event_feature_setting(event, "enable_mute_status_command"):
            yield event.plain_result("禁言状态指令已关闭。")
            return
        if not self._can_manage(event):
            yield event.plain_result("你没有本群群管权限。")
            return
        try:
            result = await QQGroupManageAPI(
                self._platform(event).client
            ).get_mute_status(event.get_group_id())
        except Exception as exc:
            yield event.plain_result(f"查询禁言状态失败：{exc}")
            return
        if not isinstance(result, dict):
            yield event.plain_result("查询禁言状态失败：接口返回格式异常。")
            return
        yield event.plain_result(format_mute_status(result))

    @filter.llm_tool(name="qq_group_mute_member")
    async def mute_tool(
        self,
        event: Any,
        member_openid: str,
        duration: str = "",
    ) -> str:
        """禁言或解禁当前 QQ 群的一名普通成员，开启严格权限审查时仅群管可用。

        Args:
            member_openid(string): 被操作成员的群成员 OpenID
            duration(string): 可选禁言时长，如 30秒、10分、2小时、1天；省略时使用插件默认时长，填 0 或 解除表示解禁
        """
        event = resolve_tool_event(event)
        if not self._is_qq_group(event):
            return "当前场景不是 QQ 官方机器人群聊，无法使用群禁言工具。"
        if not self._event_feature_setting(event, "enable_mute_tool"):
            return "QQ 群禁言工具已关闭。"
        if self._event_setting(
            event, "strict_llm_permissions", False
        ) and not self._can_manage(event):
            return "唤醒人没有本群群管权限，严格权限审查已拒绝此次工具调用。"
        try:
            duration = duration.strip() or str(
                self._event_setting(event, "default_mute_duration", "1分") or "1分"
            )
            seconds = parse_duration(duration)
            self._validate_duration(seconds, self._event_group_umo(event))
            await self._mute(event, event.get_group_id(), member_openid, seconds)
        except Exception as exc:
            return f"禁言操作失败：{exc}"
        action = "解禁" if seconds == 0 else f"禁言（时长 {duration}）"
        return f"已成功执行{action}，请根据用户语境自然回复。"

    @filter.llm_tool(name="qq_group_unmute_member")
    async def unmute_tool(
        self,
        event: Any,
        member_openid: str,
    ) -> str:
        """解除当前 QQ 群一名普通成员的禁言，开启严格权限审查时仅群管可用。

        Args:
            member_openid(string): 被解除禁言成员的群成员 OpenID
        """
        event = resolve_tool_event(event)
        if not self._is_qq_group(event):
            return "当前场景不是 QQ 官方机器人群聊，无法使用群解禁工具。"
        if not self._event_feature_setting(event, "enable_unmute_tool"):
            return "QQ 群解禁工具已关闭。"
        if self._event_setting(
            event, "strict_llm_permissions", False
        ) and not self._can_manage(event):
            return "唤醒人没有本群群管权限，严格权限审查已拒绝此次工具调用。"
        try:
            await self._mute(event, event.get_group_id(), member_openid, 0)
        except Exception as exc:
            return f"解禁操作失败：{exc}"
        return "已成功执行解禁，请根据用户语境自然回复。"

    @filter.llm_tool(name="qq_group_get_mute_status")
    async def mute_status_tool(self, event: Any) -> str:
        """查询当前 QQ 群的全员禁言规则和被禁言成员列表，开启严格权限审查时仅群管可用。"""
        event = resolve_tool_event(event)
        if not self._is_qq_group(event):
            return "当前场景不是 QQ 官方机器人群聊，无法查询群禁言状态。"
        if not self._event_feature_setting(event, "enable_mute_status_tool"):
            return "QQ 群禁言状态工具已关闭。"
        if self._event_setting(
            event, "strict_llm_permissions", False
        ) and not self._can_manage(event):
            return "唤醒人没有本群群管权限，严格权限审查已拒绝此次工具调用。"
        try:
            result = await QQGroupManageAPI(
                self._platform(event).client
            ).get_mute_status(event.get_group_id())
        except Exception as exc:
            return f"查询禁言状态失败：{exc}"
        if not isinstance(result, dict):
            return "查询禁言状态失败：接口返回格式异常。"
        return format_mute_status(result)

    @filter.llm_tool(name="qq_group_list_join_requests")
    async def list_join_requests_tool(
        self,
        event: Any,
        cursor: str = "",
        limit: int = 0,
    ) -> str:
        """拉取当前 QQ 群待处理的入群申请列表，开启严格权限审查时仅群管可用。

        Args:
            cursor(string): 分页游标，第一页传空字符串
            limit(number): 拉取条数，范围 1 到 100；省略或填 0 使用插件配置的默认条数
        """
        event = resolve_tool_event(event)
        if not self._is_qq_group(event):
            return "当前场景不是 QQ 官方机器人群聊，无法拉取入群申请。"
        if not self._event_feature_setting(event, "enable_join_list_tool"):
            return "入群申请列表工具已关闭。"
        if self._event_setting(
            event, "strict_llm_permissions", False
        ) and not self._can_manage(event):
            return "唤醒人没有本群群管权限，严格权限审查已拒绝此次工具调用。"
        platform = self._platform(event)
        try:
            result = await QQGroupManageAPI(platform.client).list_join_requests(
                event.get_group_id(),
                cursor=cursor,
                limit=limit
                or int(self._event_setting(event, "join_request_page_size", 20)),
            )
        except Exception as exc:
            return f"拉取入群申请失败：{exc}"
        items = result.get("list", []) if isinstance(result, dict) else []
        if not items:
            return "当前没有待处理的入群申请。"
        # Tool results need the identifiers consumed by the review tool;
        # public notification cards deliberately keep using format_request alone.
        text = "\n\n".join(
            f"{format_request(item)}\n"
            f"member_openid：{item.get('member_openid') or ''}\n"
            f"join_request_id：{item.get('join_request_id') or ''}"
            for item in items
        )
        next_cursor = result.get("next_cursor", "") if isinstance(result, dict) else ""
        if next_cursor:
            text += f"\n\n下一页 cursor：{next_cursor}"
        return text

    @filter.llm_tool(name="qq_group_review_join_request")
    async def review_join_request_tool(
        self,
        event: Any,
        member_openid: str,
        join_request_id: str,
        action: str,
        reject_reason: str = "",
    ) -> str:
        """同意或拒绝当前 QQ 群的某个入群申请，开启严格权限审查时仅群管可用。

        Args:
            member_openid(string): 申请人的群成员 OpenID
            join_request_id(string): 入群申请 ID
            action(string): approve 表示同意，decline 表示拒绝
            reject_reason(string): 拒绝理由，同意时留空
        """
        event = resolve_tool_event(event)
        if not self._is_qq_group(event):
            return "当前场景不是 QQ 官方机器人群聊，无法审批入群申请。"
        if not self._event_feature_setting(event, "enable_join_review_tool"):
            return "入群申请审批工具已关闭。"
        if self._event_setting(
            event, "strict_llm_permissions", False
        ) and not self._can_manage(event):
            return "唤醒人没有本群群管权限，严格权限审查已拒绝此次工具调用。"
        action = action.strip().lower()
        if action not in {"approve", "decline"}:
            return "action 只能是 approve 或 decline。"
        try:
            await self._review(
                event,
                event.get_group_id(),
                member_openid,
                join_request_id,
                action == "approve",
                reject_reason,
            )
        except Exception as exc:
            return f"审批失败：{exc}"
        if action == "approve":
            return "已同意入群申请，请根据用户语境自然回复。"
        return "已拒绝入群申请，请根据用户语境自然回复。"

    async def _mute_members(
        self, event: AstrMessageEvent, targets: list[str], seconds: int
    ) -> str | None:
        failures: list[str] = []
        for member_openid in targets:
            try:
                await self._mute(event, event.get_group_id(), member_openid, seconds)
            except Exception as exc:
                failures.append(f"- {member_openid}：{exc}")
        if not failures:
            return None
        action = "解禁" if seconds == 0 else "禁言"
        return (
            f"{action}结果：成功 {len(targets) - len(failures)} 名，"
            f"失败 {len(failures)} 名。\n失败成员：\n" + "\n".join(failures)
        )

    async def _mute(
        self,
        event: AstrMessageEvent,
        group_openid: str,
        member_openid: str,
        seconds: int,
    ) -> Any:
        return await self._mute_on_platform(
            self._platform(event), group_openid, member_openid, seconds
        )

    async def _mute_on_platform(
        self,
        platform: Any,
        group_openid: str,
        member_openid: str,
        seconds: int,
    ) -> Any:
        api = QQGroupManageAPI(platform.client)
        if seconds == 0:
            return await api.mute_member(group_openid, member_openid, op="del")
        expire_at = (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat(
            timespec="seconds"
        )
        return await api.mute_member(
            group_openid,
            member_openid,
            op="add",
            mute_expire_at=expire_at,
        )

    async def _review(
        self,
        event: AstrMessageEvent,
        group_openid: str,
        member_openid: str,
        join_request_id: str,
        approve: bool,
        reason: str,
    ) -> Any:
        request_key = (event.get_platform_id(), group_openid, join_request_id)
        if self.storage.is_reviewed(*request_key):
            raise ValueError("该入群申请已处理，请勿重复审批。")
        if request_key in self._reviews_inflight:
            raise ValueError("该入群申请正在处理中，请勿重复审批。")
        self._reviews_inflight.add(request_key)
        try:
            result = await QQGroupManageAPI(
                self._platform(event).client
            ).review_join_request(
                group_openid,
                member_openid,
                join_request_id,
                approve=approve,
                reject_reason=reason,
            )
            self._record_reviewed_request(*request_key)
            return result
        finally:
            self._reviews_inflight.discard(request_key)

    def _migrate_config_layout(self) -> None:
        """Move the old flat plugin config into the grouped dashboard layout once."""
        try:
            layout_version = int(self.config.get("config_layout_version", 0))
        except (TypeError, ValueError):
            layout_version = 0
        if layout_version >= 1:
            return
        for key in LEGACY_CONFIG_KEYS:
            if key not in self.config:
                continue
            section_name = CONFIG_SECTIONS[key]
            section = self.config.get(section_name)
            if not isinstance(section, dict):
                section = {}
                self.config[section_name] = section
            section[key] = self.config[key]
        self.config["config_layout_version"] = 1
        save = getattr(self.config, "save_config", None)
        if callable(save):
            save()

    def _config(self, key: str, default: Any = None) -> Any:
        if self.config.get("config_layout_version", 0) >= 2:
            management = self.config["group_management"]
            if key == "enable_per_group_feature_settings":
                return management["enabled"]
            section = management["global_settings"].get(CONFIG_SECTIONS.get(key), {})
            if key in section:
                return section[key]
        section_name = CONFIG_SECTIONS.get(key)
        section = self.config.get(section_name, {}) if section_name else {}
        if isinstance(section, dict) and key in section:
            return section[key]
        return self.config.get(key, default)

    def _set_config(self, key: str, value: Any) -> None:
        section_name = CONFIG_SECTIONS.get(key)
        if self.config.get("config_layout_version", 0) >= 2:
            before = deepcopy(dict(self.config))
            try:
                self.config["group_management"]["global_settings"][section_name][
                    key
                ] = value
                GroupConfig(self.config).save()
            except Exception:
                self.config.clear()
                self.config.update(before)
                raise
            return
        if section_name:
            section = self.config.get(section_name)
            if not isinstance(section, dict):
                section = {}
                self.config[section_name] = section
            section[key] = value
        else:
            self.config[key] = value
        if key in LEGACY_CONFIG_KEYS and key in self.config:
            self.config[key] = value
        save = getattr(self.config, "save_config", None)
        if callable(save):
            save()

    def _feature_setting(
        self,
        key: str,
        group_umo: str,
        default: bool = True,
    ) -> bool:
        return bool(self._group_setting(key, group_umo, default))

    def _group_setting(self, key: str, group_umo: str, default: Any = None) -> Any:
        global_value = self._config(key, default)
        if (
            not self._config("enable_per_group_feature_settings", False)
            and key not in PANEL_FEATURE_KEYS
        ):
            return global_value
        if (
            self.config.get("config_layout_version", 0) >= 2
            or key in PANEL_FEATURE_KEYS
        ):
            profile = GroupConfig(self.config).profile(group_umo)
            if profile is not None:
                return profile.get(CONFIG_SECTIONS.get(key), {}).get(key, global_value)
            return global_value
        getter = getattr(self.storage, "group_feature_override", None)
        override = getter(group_umo, key) if callable(getter) else None
        return global_value if override is None else override

    def _event_group_umo(self, event: AstrMessageEvent) -> str:
        return self._group_umo(event.get_platform_id(), event.get_group_id())

    def _event_setting(
        self, event: AstrMessageEvent, key: str, default: Any = None
    ) -> Any:
        if not self._config("enable_per_group_feature_settings", False):
            return self._config(key, default)
        return self._group_setting(key, self._event_group_umo(event), default)

    def _event_feature_setting(
        self,
        event: AstrMessageEvent,
        key: str,
        default: bool = True,
    ) -> bool:
        if (
            not self._config("enable_per_group_feature_settings", False)
            and key not in PANEL_FEATURE_KEYS
        ):
            return bool(self._config(key, default))
        return self._feature_setting(key, self._event_group_umo(event), default)

    @staticmethod
    def _qq_member_role(event: AstrMessageEvent) -> str:
        message_obj = getattr(event, "message_obj", None)
        raw_message = getattr(message_obj, "raw_message", None)
        author = getattr(raw_message, "author", None)
        role: Any = getattr(author, "member_role", "")
        if not role:
            raw_data = getattr(raw_message, "raw_data", None)
            if isinstance(raw_data, dict):
                raw_author = raw_data.get("author") or {}
                if isinstance(raw_author, dict):
                    role = raw_author.get("member_role", "")
            elif isinstance(raw_message, dict):
                raw_author = raw_message.get("author") or {}
                if isinstance(raw_author, dict):
                    role = raw_author.get("member_role", "")
        role = getattr(role, "value", role)
        normalized = str(role or "").strip().lower()
        return normalized if normalized in {"owner", "admin", "member"} else ""

    def _can_manage_plugin_admins(self, event: AstrMessageEvent) -> bool:
        if self._is_astr_admin(event):
            return True
        role = self._qq_member_role(event)
        if role == "owner":
            return bool(
                self._event_setting(
                    event, "allow_group_owner_manage_plugin_admins", False
                )
            )
        if role == "admin":
            return bool(
                self._event_setting(
                    event, "allow_group_admin_manage_plugin_admins", False
                )
            )
        return False

    @staticmethod
    def _is_astr_admin(event: AstrMessageEvent) -> bool:
        return event.get_sender_id() == event.get_self_id() or event.is_admin()

    def _platform(self, event: AstrMessageEvent) -> Any:
        platform = self.context.get_platform_inst(event.get_platform_id())
        if platform is None or not hasattr(platform, "client"):
            raise RuntimeError("找不到当前 QQ 官方平台实例")
        return platform

    def _is_qq_group(self, event: AstrMessageEvent) -> bool:
        return (
            event.get_platform_name() in QQ_PLATFORMS
            and bool(event.get_group_id())
            and self._umo_enabled(self._event_group_umo(event))
        )

    def _umo_enabled(self, umo: str) -> bool:
        configured = self._config("enabled_group_umos", []) or []
        if isinstance(configured, str):
            configured = [configured]
        whitelist = {str(item).strip() for item in configured if str(item).strip()}
        return not whitelist or umo in whitelist

    async def _sdk_group_enabled(self, umo: str, actor_id: str = "") -> bool:
        if not self._umo_enabled(umo):
            return False
        try:
            config = self.context.get_config(umo)
            plugins = config.get("plugin_set", ["*"])
            if plugins != ["*"] and not ({PLUGIN_NAME, *LEGACY_PLUGIN_NAMES} & {
                str(item) for item in plugins
            }):
                return False
            # 生命周期检查真实群；按钮回调还需检查点击者的隔离会话。
            settings = config.get("platform_settings", {})
            whitelist = {
                str(value).strip()
                for value in settings.get("id_whitelist", [])
                if str(value).strip()
            }
            group_id = umo.split(":", 2)[-1]
            actor_umo = umo
            if actor_id and settings.get("unique_session", False):
                actor_umo = f"{umo.rsplit(':', 1)[0]}:{actor_id}_{group_id}"
            exempt = bool(
                actor_id
                and actor_id in config.get("admins_id", [])
                and settings.get("wl_ignore_admin_on_group", False)
            )
            if settings.get("enable_id_white_list") and whitelist and not exempt:
                if actor_umo not in whitelist and group_id not in whitelist:
                    return False
            for session in dict.fromkeys((umo, actor_umo)):
                if not await SessionServiceManager.is_session_enabled(session):
                    return False
                if not await SessionPluginManager.is_plugin_enabled_for_session(
                    session, PLUGIN_NAME
                ):
                    return False
            return True
        except Exception:
            logger.exception("[%s] 无法读取会话插件状态，已拒绝 SDK 事件", PLUGIN_NAME)
            return False

    @staticmethod
    def _group_umo(platform_id: str, group_openid: str) -> str:
        return f"{platform_id}:GroupMessage:{group_openid}"

    def _can_manage(self, event: AstrMessageEvent) -> bool:
        get_admins = getattr(self.storage, "group_admins", None)
        group_admins = get_admins(event.get_group_id()) if callable(get_admins) else []
        return (
            event.get_sender_id() == event.get_self_id()
            or event.is_admin()
            or event.get_sender_id() in group_admins
            or self._qq_member_role(event) in {"owner", "admin"}
        )

    def _mentioned_members(
        self, event: AstrMessageEvent, limit: int = 10
    ) -> list[str]:
        raw = getattr(event.message_obj, "raw_message", None)
        mentions = getattr(raw, "mentions", None) or []
        targets: list[str] = []
        for mention in mentions:
            if getattr(mention, "is_you", False):
                continue
            member_openid = getattr(mention, "member_openid", None) or getattr(
                mention, "id", None
            )
            if member_openid and str(member_openid) not in targets:
                targets.append(str(member_openid))
        # Fallback for adapters that preserve At components directly.
        for part in event.get_messages():
            if isinstance(part, At) and str(part.qq) not in {
                "qq_official",
                event.get_self_id(),
                "all",
            }:
                if str(part.qq) not in targets:
                    targets.append(str(part.qq))
        return targets[: max(1, min(int(limit), 20))]

    def _validate_duration(self, seconds: int, group_umo: str = "") -> None:
        maximum = max(
            1, int(self._group_setting("max_mute_seconds", group_umo, 2592000))
        )
        if seconds < 0 or seconds > maximum:
            raise ValueError(f"禁言时长必须在 0 到 {maximum} 秒之间")

    @staticmethod
    def _response_id(result: Any) -> str:
        if isinstance(result, dict):
            return str(result.get("id") or "")
        return str(getattr(result, "id", "") or "")

    @staticmethod
    def _restore_client_handlers(state: dict[str, Any]) -> None:
        for connection, old_parsers, owned_parsers in state["connections"].values():
            for name, parser in owned_parsers.items():
                if connection.parser.get(name) is not parser:
                    continue
                if old_parsers[name] is None:
                    connection.parser.pop(name, None)
                else:
                    connection.parser[name] = old_parsers[name]
        client = state["client"]
        for attr, old_handler in state["old_handlers"].items():
            if getattr(client, attr, None) is not state["owned_handlers"][attr]:
                continue
            if old_handler is None:
                delattr(client, attr)
            else:
                setattr(client, attr, old_handler)

    async def terminate(self) -> None:
        self._terminating = True
        server_status = getattr(self, "server_status", None)
        if server_status is not None:
            await server_status.stop()
        dashboard = getattr(self, "dashboard", None)
        if dashboard is not None:
            dashboard.unregister()
        for state in self._patched.values():
            self._restore_client_handlers(state)
        self._patched.clear()
        state_class = self._parser_state_class
        if state_class is not None:
            for attr, parser in self._owned_parser_methods.items():
                if getattr(state_class, attr, None) is parser:
                    delattr(state_class, attr)
        self._owned_parser_methods.clear()
        self._parser_state_class = None
        # Finish cancellation cleanup (including pending-state writes) before a
        # reloaded instance reads state.json. Never leave an old snapshot writer alive.
        tasks = list(self._sdk_event_tasks)
        if self._patch_task is not None:
            tasks.append(self._patch_task)
        if self._verify_task is not None:
            tasks.append(self._verify_task)
        if self._qr_dep_task is not None:
            tasks.append(self._qr_dep_task)
        for task in tasks:
            task.cancel()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for result in results:
            if isinstance(result, Exception):
                logger.error("[%s] 清理后台任务时出错：%r", PLUGIN_NAME, result)
        self._sdk_event_tasks.clear()
        self._patch_task = None
        self._verify_task = None
        self._qr_dep_task = None
        self.spam_monitor.clear()
        self.recall_monitor.clear()


def render_member_notice(
    template: str,
    member_openid: str,
    *,
    can_at: bool,
    appid: str = "",
) -> str:
    """Render member placeholders for lifecycle notices."""
    if can_at and member_openid:
        member_value = f'<qqbot-at-user id="{member_openid}" />'
    else:
        member_value = member_openid or "未知成员"
    avatar_value = ""
    if appid and member_openid:
        avatar_url = (
            "https://q.qlogo.cn/qqapp/"
            f"{quote(appid, safe='')}/{quote(member_openid, safe='')}/640"
        )

        def avatar_repl(match: re.Match[str]) -> str:
            size = int(match.group(1) or 100)
            size = max(24, min(size, 320))
            return f"![头像 #{size}px #{size}px]({avatar_url})"

        template = re.sub(r"\{member_avatar(?::(\d+))?\}", avatar_repl, template)
    return template.replace("{member_at}", member_value).replace(
        "{member_avatar}", avatar_value
    )


def extract_mute_duration(
    message_text: str,
    default_duration: str,
) -> str:
    """Extract duration without letting command executors turn mentions into args."""
    text = re.sub(r"^/?禁言\s*", "", message_text.strip())
    text = re.sub(r"<qqbot-at-user\b[^>]*/?>", "", text, flags=re.I)
    text = re.sub(r"<@!?[^>]+>", "", text).strip()
    text = re.sub(r"(?<!\S)@\S+", "", text).strip()
    return text or default_duration.strip() or "1分"
